package com.vinay.cdr.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.vinay.cdr.web.rest.TestUtil;

public class CashDrawerTxnResultTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(CashDrawerTxnResult.class);
        CashDrawerTxnResult cashDrawerTxnResult1 = new CashDrawerTxnResult();
        cashDrawerTxnResult1.setId(1L);
        CashDrawerTxnResult cashDrawerTxnResult2 = new CashDrawerTxnResult();
        cashDrawerTxnResult2.setId(cashDrawerTxnResult1.getId());
        assertThat(cashDrawerTxnResult1).isEqualTo(cashDrawerTxnResult2);
        cashDrawerTxnResult2.setId(2L);
        assertThat(cashDrawerTxnResult1).isNotEqualTo(cashDrawerTxnResult2);
        cashDrawerTxnResult1.setId(null);
        assertThat(cashDrawerTxnResult1).isNotEqualTo(cashDrawerTxnResult2);
    }
}
