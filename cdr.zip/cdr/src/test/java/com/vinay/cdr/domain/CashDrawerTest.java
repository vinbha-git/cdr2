package com.vinay.cdr.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.vinay.cdr.web.rest.TestUtil;

public class CashDrawerTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(CashDrawer.class);
        CashDrawer cashDrawer1 = new CashDrawer();
        cashDrawer1.setId(1L);
        CashDrawer cashDrawer2 = new CashDrawer();
        cashDrawer2.setId(cashDrawer1.getId());
        assertThat(cashDrawer1).isEqualTo(cashDrawer2);
        cashDrawer2.setId(2L);
        assertThat(cashDrawer1).isNotEqualTo(cashDrawer2);
        cashDrawer1.setId(null);
        assertThat(cashDrawer1).isNotEqualTo(cashDrawer2);
    }
}
