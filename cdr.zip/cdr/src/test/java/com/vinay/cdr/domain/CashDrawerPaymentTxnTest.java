package com.vinay.cdr.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.vinay.cdr.web.rest.TestUtil;

public class CashDrawerPaymentTxnTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(CashDrawerPaymentTxn.class);
        CashDrawerPaymentTxn cashDrawerPaymentTxn1 = new CashDrawerPaymentTxn();
        cashDrawerPaymentTxn1.setId(1L);
        CashDrawerPaymentTxn cashDrawerPaymentTxn2 = new CashDrawerPaymentTxn();
        cashDrawerPaymentTxn2.setId(cashDrawerPaymentTxn1.getId());
        assertThat(cashDrawerPaymentTxn1).isEqualTo(cashDrawerPaymentTxn2);
        cashDrawerPaymentTxn2.setId(2L);
        assertThat(cashDrawerPaymentTxn1).isNotEqualTo(cashDrawerPaymentTxn2);
        cashDrawerPaymentTxn1.setId(null);
        assertThat(cashDrawerPaymentTxn1).isNotEqualTo(cashDrawerPaymentTxn2);
    }
}
