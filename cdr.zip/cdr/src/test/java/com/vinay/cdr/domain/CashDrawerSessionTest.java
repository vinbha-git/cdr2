package com.vinay.cdr.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.vinay.cdr.web.rest.TestUtil;

public class CashDrawerSessionTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(CashDrawerSession.class);
        CashDrawerSession cashDrawerSession1 = new CashDrawerSession();
        cashDrawerSession1.setId(1L);
        CashDrawerSession cashDrawerSession2 = new CashDrawerSession();
        cashDrawerSession2.setId(cashDrawerSession1.getId());
        assertThat(cashDrawerSession1).isEqualTo(cashDrawerSession2);
        cashDrawerSession2.setId(2L);
        assertThat(cashDrawerSession1).isNotEqualTo(cashDrawerSession2);
        cashDrawerSession1.setId(null);
        assertThat(cashDrawerSession1).isNotEqualTo(cashDrawerSession2);
    }
}
