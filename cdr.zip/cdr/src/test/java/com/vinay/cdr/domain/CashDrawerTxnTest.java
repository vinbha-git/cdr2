package com.vinay.cdr.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.vinay.cdr.web.rest.TestUtil;

public class CashDrawerTxnTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(CashDrawerTxn.class);
        CashDrawerTxn cashDrawerTxn1 = new CashDrawerTxn();
        cashDrawerTxn1.setId(1L);
        CashDrawerTxn cashDrawerTxn2 = new CashDrawerTxn();
        cashDrawerTxn2.setId(cashDrawerTxn1.getId());
        assertThat(cashDrawerTxn1).isEqualTo(cashDrawerTxn2);
        cashDrawerTxn2.setId(2L);
        assertThat(cashDrawerTxn1).isNotEqualTo(cashDrawerTxn2);
        cashDrawerTxn1.setId(null);
        assertThat(cashDrawerTxn1).isNotEqualTo(cashDrawerTxn2);
    }
}
