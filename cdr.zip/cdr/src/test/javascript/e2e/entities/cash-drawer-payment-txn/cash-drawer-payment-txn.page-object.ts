import { element, by, ElementFinder } from 'protractor';

export class CashDrawerPaymentTxnComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-cash-drawer-payment-txn div table .btn-danger'));
  title = element.all(by.css('jhi-cash-drawer-payment-txn div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getAttribute('jhiTranslate');
  }
}

export class CashDrawerPaymentTxnUpdatePage {
  pageTitle = element(by.id('jhi-cash-drawer-payment-txn-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  txnDateInput = element(by.id('field_txnDate'));
  customerFirstNameInput = element(by.id('field_customerFirstName'));
  customerLastNameInput = element(by.id('field_customerLastName'));
  customerNbrInput = element(by.id('field_customerNbr'));
  customerPhoneInput = element(by.id('field_customerPhone'));
  cstomerAccountNumberInput = element(by.id('field_cstomerAccountNumber'));
  dueAmtInput = element(by.id('field_dueAmt'));
  cashAmtInput = element(by.id('field_cashAmt'));
  checkAmtInput = element(by.id('field_checkAmt'));
  posAmtInput = element(by.id('field_posAmt'));
  changeAmtInput = element(by.id('field_changeAmt'));
  checkNumberInput = element(by.id('field_checkNumber'));
  posReferenceInput = element(by.id('field_posReference'));
  createdByInput = element(by.id('field_createdBy'));
  creationDateInput = element(by.id('field_creationDate'));
  lastUpdatedByInput = element(by.id('field_lastUpdatedBy'));
  lastUpdateDateInput = element(by.id('field_lastUpdateDate'));

  cashDrawerSessionSelect = element(by.id('field_cashDrawerSession'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getAttribute('jhiTranslate');
  }

  async setTxnDateInput(txnDate: string): Promise<void> {
    await this.txnDateInput.sendKeys(txnDate);
  }

  async getTxnDateInput(): Promise<string> {
    return await this.txnDateInput.getAttribute('value');
  }

  async setCustomerFirstNameInput(customerFirstName: string): Promise<void> {
    await this.customerFirstNameInput.sendKeys(customerFirstName);
  }

  async getCustomerFirstNameInput(): Promise<string> {
    return await this.customerFirstNameInput.getAttribute('value');
  }

  async setCustomerLastNameInput(customerLastName: string): Promise<void> {
    await this.customerLastNameInput.sendKeys(customerLastName);
  }

  async getCustomerLastNameInput(): Promise<string> {
    return await this.customerLastNameInput.getAttribute('value');
  }

  async setCustomerNbrInput(customerNbr: string): Promise<void> {
    await this.customerNbrInput.sendKeys(customerNbr);
  }

  async getCustomerNbrInput(): Promise<string> {
    return await this.customerNbrInput.getAttribute('value');
  }

  async setCustomerPhoneInput(customerPhone: string): Promise<void> {
    await this.customerPhoneInput.sendKeys(customerPhone);
  }

  async getCustomerPhoneInput(): Promise<string> {
    return await this.customerPhoneInput.getAttribute('value');
  }

  async setCstomerAccountNumberInput(cstomerAccountNumber: string): Promise<void> {
    await this.cstomerAccountNumberInput.sendKeys(cstomerAccountNumber);
  }

  async getCstomerAccountNumberInput(): Promise<string> {
    return await this.cstomerAccountNumberInput.getAttribute('value');
  }

  async setDueAmtInput(dueAmt: string): Promise<void> {
    await this.dueAmtInput.sendKeys(dueAmt);
  }

  async getDueAmtInput(): Promise<string> {
    return await this.dueAmtInput.getAttribute('value');
  }

  async setCashAmtInput(cashAmt: string): Promise<void> {
    await this.cashAmtInput.sendKeys(cashAmt);
  }

  async getCashAmtInput(): Promise<string> {
    return await this.cashAmtInput.getAttribute('value');
  }

  async setCheckAmtInput(checkAmt: string): Promise<void> {
    await this.checkAmtInput.sendKeys(checkAmt);
  }

  async getCheckAmtInput(): Promise<string> {
    return await this.checkAmtInput.getAttribute('value');
  }

  async setPosAmtInput(posAmt: string): Promise<void> {
    await this.posAmtInput.sendKeys(posAmt);
  }

  async getPosAmtInput(): Promise<string> {
    return await this.posAmtInput.getAttribute('value');
  }

  async setChangeAmtInput(changeAmt: string): Promise<void> {
    await this.changeAmtInput.sendKeys(changeAmt);
  }

  async getChangeAmtInput(): Promise<string> {
    return await this.changeAmtInput.getAttribute('value');
  }

  async setCheckNumberInput(checkNumber: string): Promise<void> {
    await this.checkNumberInput.sendKeys(checkNumber);
  }

  async getCheckNumberInput(): Promise<string> {
    return await this.checkNumberInput.getAttribute('value');
  }

  async setPosReferenceInput(posReference: string): Promise<void> {
    await this.posReferenceInput.sendKeys(posReference);
  }

  async getPosReferenceInput(): Promise<string> {
    return await this.posReferenceInput.getAttribute('value');
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setCreationDateInput(creationDate: string): Promise<void> {
    await this.creationDateInput.sendKeys(creationDate);
  }

  async getCreationDateInput(): Promise<string> {
    return await this.creationDateInput.getAttribute('value');
  }

  async setLastUpdatedByInput(lastUpdatedBy: string): Promise<void> {
    await this.lastUpdatedByInput.sendKeys(lastUpdatedBy);
  }

  async getLastUpdatedByInput(): Promise<string> {
    return await this.lastUpdatedByInput.getAttribute('value');
  }

  async setLastUpdateDateInput(lastUpdateDate: string): Promise<void> {
    await this.lastUpdateDateInput.sendKeys(lastUpdateDate);
  }

  async getLastUpdateDateInput(): Promise<string> {
    return await this.lastUpdateDateInput.getAttribute('value');
  }

  async cashDrawerSessionSelectLastOption(): Promise<void> {
    await this.cashDrawerSessionSelect.all(by.tagName('option')).last().click();
  }

  async cashDrawerSessionSelectOption(option: string): Promise<void> {
    await this.cashDrawerSessionSelect.sendKeys(option);
  }

  getCashDrawerSessionSelect(): ElementFinder {
    return this.cashDrawerSessionSelect;
  }

  async getCashDrawerSessionSelectedOption(): Promise<string> {
    return await this.cashDrawerSessionSelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class CashDrawerPaymentTxnDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-cashDrawerPaymentTxn-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-cashDrawerPaymentTxn'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getAttribute('jhiTranslate');
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
