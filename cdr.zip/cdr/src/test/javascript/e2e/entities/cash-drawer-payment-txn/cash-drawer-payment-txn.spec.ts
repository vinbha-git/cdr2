import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import {
  CashDrawerPaymentTxnComponentsPage,
  CashDrawerPaymentTxnDeleteDialog,
  CashDrawerPaymentTxnUpdatePage,
} from './cash-drawer-payment-txn.page-object';

const expect = chai.expect;

describe('CashDrawerPaymentTxn e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let cashDrawerPaymentTxnComponentsPage: CashDrawerPaymentTxnComponentsPage;
  let cashDrawerPaymentTxnUpdatePage: CashDrawerPaymentTxnUpdatePage;
  let cashDrawerPaymentTxnDeleteDialog: CashDrawerPaymentTxnDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load CashDrawerPaymentTxns', async () => {
    await navBarPage.goToEntity('cash-drawer-payment-txn');
    cashDrawerPaymentTxnComponentsPage = new CashDrawerPaymentTxnComponentsPage();
    await browser.wait(ec.visibilityOf(cashDrawerPaymentTxnComponentsPage.title), 5000);
    expect(await cashDrawerPaymentTxnComponentsPage.getTitle()).to.eq('cdrApp.cashDrawerPaymentTxn.home.title');
    await browser.wait(
      ec.or(ec.visibilityOf(cashDrawerPaymentTxnComponentsPage.entities), ec.visibilityOf(cashDrawerPaymentTxnComponentsPage.noResult)),
      1000
    );
  });

  it('should load create CashDrawerPaymentTxn page', async () => {
    await cashDrawerPaymentTxnComponentsPage.clickOnCreateButton();
    cashDrawerPaymentTxnUpdatePage = new CashDrawerPaymentTxnUpdatePage();
    expect(await cashDrawerPaymentTxnUpdatePage.getPageTitle()).to.eq('cdrApp.cashDrawerPaymentTxn.home.createOrEditLabel');
    await cashDrawerPaymentTxnUpdatePage.cancel();
  });

  it('should create and save CashDrawerPaymentTxns', async () => {
    const nbButtonsBeforeCreate = await cashDrawerPaymentTxnComponentsPage.countDeleteButtons();

    await cashDrawerPaymentTxnComponentsPage.clickOnCreateButton();

    await promise.all([
      cashDrawerPaymentTxnUpdatePage.setTxnDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerPaymentTxnUpdatePage.setCustomerFirstNameInput('customerFirstName'),
      cashDrawerPaymentTxnUpdatePage.setCustomerLastNameInput('customerLastName'),
      cashDrawerPaymentTxnUpdatePage.setCustomerNbrInput('customerNbr'),
      cashDrawerPaymentTxnUpdatePage.setCustomerPhoneInput('5'),
      cashDrawerPaymentTxnUpdatePage.setCstomerAccountNumberInput('cstomerAccountNumber'),
      cashDrawerPaymentTxnUpdatePage.setDueAmtInput('5'),
      cashDrawerPaymentTxnUpdatePage.setCashAmtInput('5'),
      cashDrawerPaymentTxnUpdatePage.setCheckAmtInput('5'),
      cashDrawerPaymentTxnUpdatePage.setPosAmtInput('5'),
      cashDrawerPaymentTxnUpdatePage.setChangeAmtInput('5'),
      cashDrawerPaymentTxnUpdatePage.setCheckNumberInput('checkNumber'),
      cashDrawerPaymentTxnUpdatePage.setPosReferenceInput('posReference'),
      cashDrawerPaymentTxnUpdatePage.setCreatedByInput('createdBy'),
      cashDrawerPaymentTxnUpdatePage.setCreationDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerPaymentTxnUpdatePage.setLastUpdatedByInput('lastUpdatedBy'),
      cashDrawerPaymentTxnUpdatePage.setLastUpdateDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerPaymentTxnUpdatePage.cashDrawerSessionSelectLastOption(),
    ]);

    expect(await cashDrawerPaymentTxnUpdatePage.getTxnDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected txnDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCustomerFirstNameInput()).to.eq(
      'customerFirstName',
      'Expected CustomerFirstName value to be equals to customerFirstName'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCustomerLastNameInput()).to.eq(
      'customerLastName',
      'Expected CustomerLastName value to be equals to customerLastName'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCustomerNbrInput()).to.eq(
      'customerNbr',
      'Expected CustomerNbr value to be equals to customerNbr'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCustomerPhoneInput()).to.eq('5', 'Expected customerPhone value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getCstomerAccountNumberInput()).to.eq(
      'cstomerAccountNumber',
      'Expected CstomerAccountNumber value to be equals to cstomerAccountNumber'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getDueAmtInput()).to.eq('5', 'Expected dueAmt value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getCashAmtInput()).to.eq('5', 'Expected cashAmt value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getCheckAmtInput()).to.eq('5', 'Expected checkAmt value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getPosAmtInput()).to.eq('5', 'Expected posAmt value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getChangeAmtInput()).to.eq('5', 'Expected changeAmt value to be equals to 5');
    expect(await cashDrawerPaymentTxnUpdatePage.getCheckNumberInput()).to.eq(
      'checkNumber',
      'Expected CheckNumber value to be equals to checkNumber'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getPosReferenceInput()).to.eq(
      'posReference',
      'Expected PosReference value to be equals to posReference'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCreatedByInput()).to.eq(
      'createdBy',
      'Expected CreatedBy value to be equals to createdBy'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getCreationDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected creationDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getLastUpdatedByInput()).to.eq(
      'lastUpdatedBy',
      'Expected LastUpdatedBy value to be equals to lastUpdatedBy'
    );
    expect(await cashDrawerPaymentTxnUpdatePage.getLastUpdateDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected lastUpdateDate value to be equals to 2000-12-31'
    );

    await cashDrawerPaymentTxnUpdatePage.save();
    expect(await cashDrawerPaymentTxnUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await cashDrawerPaymentTxnComponentsPage.countDeleteButtons()).to.eq(
      nbButtonsBeforeCreate + 1,
      'Expected one more entry in the table'
    );
  });

  it('should delete last CashDrawerPaymentTxn', async () => {
    const nbButtonsBeforeDelete = await cashDrawerPaymentTxnComponentsPage.countDeleteButtons();
    await cashDrawerPaymentTxnComponentsPage.clickOnLastDeleteButton();

    cashDrawerPaymentTxnDeleteDialog = new CashDrawerPaymentTxnDeleteDialog();
    expect(await cashDrawerPaymentTxnDeleteDialog.getDialogTitle()).to.eq('cdrApp.cashDrawerPaymentTxn.delete.question');
    await cashDrawerPaymentTxnDeleteDialog.clickOnConfirmButton();

    expect(await cashDrawerPaymentTxnComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
