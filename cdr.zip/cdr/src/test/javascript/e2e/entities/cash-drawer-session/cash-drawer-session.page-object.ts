import { element, by, ElementFinder } from 'protractor';

export class CashDrawerSessionComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-cash-drawer-session div table .btn-danger'));
  title = element.all(by.css('jhi-cash-drawer-session div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getAttribute('jhiTranslate');
  }
}

export class CashDrawerSessionUpdatePage {
  pageTitle = element(by.id('jhi-cash-drawer-session-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  currentIndicatorInput = element(by.id('field_currentIndicator'));
  cashierUsrCodeInput = element(by.id('field_cashierUsrCode'));
  cashOpenInput = element(by.id('field_cashOpen'));
  cashCurrentInput = element(by.id('field_cashCurrent'));
  cashCloseInput = element(by.id('field_cashClose'));
  checkOpenInput = element(by.id('field_checkOpen'));
  checkCurrentInput = element(by.id('field_checkCurrent'));
  checkCloseInput = element(by.id('field_checkClose'));
  posOpenInput = element(by.id('field_posOpen'));
  posCurrentInput = element(by.id('field_posCurrent'));
  posCloseInput = element(by.id('field_posClose'));
  sessionStartTimeInput = element(by.id('field_sessionStartTime'));
  sessionEndTimeInput = element(by.id('field_sessionEndTime'));
  createdByInput = element(by.id('field_createdBy'));
  creationDateInput = element(by.id('field_creationDate'));
  lastUpdatedByInput = element(by.id('field_lastUpdatedBy'));
  lastUpdateDateInput = element(by.id('field_lastUpdateDate'));

  cashDrawerSelect = element(by.id('field_cashDrawer'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getAttribute('jhiTranslate');
  }

  getCurrentIndicatorInput(): ElementFinder {
    return this.currentIndicatorInput;
  }

  async setCashierUsrCodeInput(cashierUsrCode: string): Promise<void> {
    await this.cashierUsrCodeInput.sendKeys(cashierUsrCode);
  }

  async getCashierUsrCodeInput(): Promise<string> {
    return await this.cashierUsrCodeInput.getAttribute('value');
  }

  async setCashOpenInput(cashOpen: string): Promise<void> {
    await this.cashOpenInput.sendKeys(cashOpen);
  }

  async getCashOpenInput(): Promise<string> {
    return await this.cashOpenInput.getAttribute('value');
  }

  async setCashCurrentInput(cashCurrent: string): Promise<void> {
    await this.cashCurrentInput.sendKeys(cashCurrent);
  }

  async getCashCurrentInput(): Promise<string> {
    return await this.cashCurrentInput.getAttribute('value');
  }

  async setCashCloseInput(cashClose: string): Promise<void> {
    await this.cashCloseInput.sendKeys(cashClose);
  }

  async getCashCloseInput(): Promise<string> {
    return await this.cashCloseInput.getAttribute('value');
  }

  async setCheckOpenInput(checkOpen: string): Promise<void> {
    await this.checkOpenInput.sendKeys(checkOpen);
  }

  async getCheckOpenInput(): Promise<string> {
    return await this.checkOpenInput.getAttribute('value');
  }

  async setCheckCurrentInput(checkCurrent: string): Promise<void> {
    await this.checkCurrentInput.sendKeys(checkCurrent);
  }

  async getCheckCurrentInput(): Promise<string> {
    return await this.checkCurrentInput.getAttribute('value');
  }

  async setCheckCloseInput(checkClose: string): Promise<void> {
    await this.checkCloseInput.sendKeys(checkClose);
  }

  async getCheckCloseInput(): Promise<string> {
    return await this.checkCloseInput.getAttribute('value');
  }

  async setPosOpenInput(posOpen: string): Promise<void> {
    await this.posOpenInput.sendKeys(posOpen);
  }

  async getPosOpenInput(): Promise<string> {
    return await this.posOpenInput.getAttribute('value');
  }

  async setPosCurrentInput(posCurrent: string): Promise<void> {
    await this.posCurrentInput.sendKeys(posCurrent);
  }

  async getPosCurrentInput(): Promise<string> {
    return await this.posCurrentInput.getAttribute('value');
  }

  async setPosCloseInput(posClose: string): Promise<void> {
    await this.posCloseInput.sendKeys(posClose);
  }

  async getPosCloseInput(): Promise<string> {
    return await this.posCloseInput.getAttribute('value');
  }

  async setSessionStartTimeInput(sessionStartTime: string): Promise<void> {
    await this.sessionStartTimeInput.sendKeys(sessionStartTime);
  }

  async getSessionStartTimeInput(): Promise<string> {
    return await this.sessionStartTimeInput.getAttribute('value');
  }

  async setSessionEndTimeInput(sessionEndTime: string): Promise<void> {
    await this.sessionEndTimeInput.sendKeys(sessionEndTime);
  }

  async getSessionEndTimeInput(): Promise<string> {
    return await this.sessionEndTimeInput.getAttribute('value');
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setCreationDateInput(creationDate: string): Promise<void> {
    await this.creationDateInput.sendKeys(creationDate);
  }

  async getCreationDateInput(): Promise<string> {
    return await this.creationDateInput.getAttribute('value');
  }

  async setLastUpdatedByInput(lastUpdatedBy: string): Promise<void> {
    await this.lastUpdatedByInput.sendKeys(lastUpdatedBy);
  }

  async getLastUpdatedByInput(): Promise<string> {
    return await this.lastUpdatedByInput.getAttribute('value');
  }

  async setLastUpdateDateInput(lastUpdateDate: string): Promise<void> {
    await this.lastUpdateDateInput.sendKeys(lastUpdateDate);
  }

  async getLastUpdateDateInput(): Promise<string> {
    return await this.lastUpdateDateInput.getAttribute('value');
  }

  async cashDrawerSelectLastOption(): Promise<void> {
    await this.cashDrawerSelect.all(by.tagName('option')).last().click();
  }

  async cashDrawerSelectOption(option: string): Promise<void> {
    await this.cashDrawerSelect.sendKeys(option);
  }

  getCashDrawerSelect(): ElementFinder {
    return this.cashDrawerSelect;
  }

  async getCashDrawerSelectedOption(): Promise<string> {
    return await this.cashDrawerSelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class CashDrawerSessionDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-cashDrawerSession-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-cashDrawerSession'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getAttribute('jhiTranslate');
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
