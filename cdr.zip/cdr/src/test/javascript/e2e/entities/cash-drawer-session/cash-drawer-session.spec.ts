import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import {
  CashDrawerSessionComponentsPage,
  CashDrawerSessionDeleteDialog,
  CashDrawerSessionUpdatePage,
} from './cash-drawer-session.page-object';

const expect = chai.expect;

describe('CashDrawerSession e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let cashDrawerSessionComponentsPage: CashDrawerSessionComponentsPage;
  let cashDrawerSessionUpdatePage: CashDrawerSessionUpdatePage;
  let cashDrawerSessionDeleteDialog: CashDrawerSessionDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load CashDrawerSessions', async () => {
    await navBarPage.goToEntity('cash-drawer-session');
    cashDrawerSessionComponentsPage = new CashDrawerSessionComponentsPage();
    await browser.wait(ec.visibilityOf(cashDrawerSessionComponentsPage.title), 5000);
    expect(await cashDrawerSessionComponentsPage.getTitle()).to.eq('cdrApp.cashDrawerSession.home.title');
    await browser.wait(
      ec.or(ec.visibilityOf(cashDrawerSessionComponentsPage.entities), ec.visibilityOf(cashDrawerSessionComponentsPage.noResult)),
      1000
    );
  });

  it('should load create CashDrawerSession page', async () => {
    await cashDrawerSessionComponentsPage.clickOnCreateButton();
    cashDrawerSessionUpdatePage = new CashDrawerSessionUpdatePage();
    expect(await cashDrawerSessionUpdatePage.getPageTitle()).to.eq('cdrApp.cashDrawerSession.home.createOrEditLabel');
    await cashDrawerSessionUpdatePage.cancel();
  });

  it('should create and save CashDrawerSessions', async () => {
    const nbButtonsBeforeCreate = await cashDrawerSessionComponentsPage.countDeleteButtons();

    await cashDrawerSessionComponentsPage.clickOnCreateButton();

    await promise.all([
      cashDrawerSessionUpdatePage.setCashierUsrCodeInput('cashierUsrCode'),
      cashDrawerSessionUpdatePage.setCashOpenInput('5'),
      cashDrawerSessionUpdatePage.setCashCurrentInput('5'),
      cashDrawerSessionUpdatePage.setCashCloseInput('5'),
      cashDrawerSessionUpdatePage.setCheckOpenInput('5'),
      cashDrawerSessionUpdatePage.setCheckCurrentInput('5'),
      cashDrawerSessionUpdatePage.setCheckCloseInput('5'),
      cashDrawerSessionUpdatePage.setPosOpenInput('5'),
      cashDrawerSessionUpdatePage.setPosCurrentInput('5'),
      cashDrawerSessionUpdatePage.setPosCloseInput('5'),
      cashDrawerSessionUpdatePage.setSessionStartTimeInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerSessionUpdatePage.setSessionEndTimeInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerSessionUpdatePage.setCreatedByInput('createdBy'),
      cashDrawerSessionUpdatePage.setCreationDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerSessionUpdatePage.setLastUpdatedByInput('lastUpdatedBy'),
      cashDrawerSessionUpdatePage.setLastUpdateDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerSessionUpdatePage.cashDrawerSelectLastOption(),
    ]);

    const selectedCurrentIndicator = cashDrawerSessionUpdatePage.getCurrentIndicatorInput();
    if (await selectedCurrentIndicator.isSelected()) {
      await cashDrawerSessionUpdatePage.getCurrentIndicatorInput().click();
      expect(await cashDrawerSessionUpdatePage.getCurrentIndicatorInput().isSelected(), 'Expected currentIndicator not to be selected').to
        .be.false;
    } else {
      await cashDrawerSessionUpdatePage.getCurrentIndicatorInput().click();
      expect(await cashDrawerSessionUpdatePage.getCurrentIndicatorInput().isSelected(), 'Expected currentIndicator to be selected').to.be
        .true;
    }
    expect(await cashDrawerSessionUpdatePage.getCashierUsrCodeInput()).to.eq(
      'cashierUsrCode',
      'Expected CashierUsrCode value to be equals to cashierUsrCode'
    );
    expect(await cashDrawerSessionUpdatePage.getCashOpenInput()).to.eq('5', 'Expected cashOpen value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getCashCurrentInput()).to.eq('5', 'Expected cashCurrent value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getCashCloseInput()).to.eq('5', 'Expected cashClose value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getCheckOpenInput()).to.eq('5', 'Expected checkOpen value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getCheckCurrentInput()).to.eq('5', 'Expected checkCurrent value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getCheckCloseInput()).to.eq('5', 'Expected checkClose value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getPosOpenInput()).to.eq('5', 'Expected posOpen value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getPosCurrentInput()).to.eq('5', 'Expected posCurrent value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getPosCloseInput()).to.eq('5', 'Expected posClose value to be equals to 5');
    expect(await cashDrawerSessionUpdatePage.getSessionStartTimeInput()).to.contain(
      '2001-01-01T02:30',
      'Expected sessionStartTime value to be equals to 2000-12-31'
    );
    expect(await cashDrawerSessionUpdatePage.getSessionEndTimeInput()).to.contain(
      '2001-01-01T02:30',
      'Expected sessionEndTime value to be equals to 2000-12-31'
    );
    expect(await cashDrawerSessionUpdatePage.getCreatedByInput()).to.eq('createdBy', 'Expected CreatedBy value to be equals to createdBy');
    expect(await cashDrawerSessionUpdatePage.getCreationDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected creationDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerSessionUpdatePage.getLastUpdatedByInput()).to.eq(
      'lastUpdatedBy',
      'Expected LastUpdatedBy value to be equals to lastUpdatedBy'
    );
    expect(await cashDrawerSessionUpdatePage.getLastUpdateDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected lastUpdateDate value to be equals to 2000-12-31'
    );

    await cashDrawerSessionUpdatePage.save();
    expect(await cashDrawerSessionUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await cashDrawerSessionComponentsPage.countDeleteButtons()).to.eq(
      nbButtonsBeforeCreate + 1,
      'Expected one more entry in the table'
    );
  });

  it('should delete last CashDrawerSession', async () => {
    const nbButtonsBeforeDelete = await cashDrawerSessionComponentsPage.countDeleteButtons();
    await cashDrawerSessionComponentsPage.clickOnLastDeleteButton();

    cashDrawerSessionDeleteDialog = new CashDrawerSessionDeleteDialog();
    expect(await cashDrawerSessionDeleteDialog.getDialogTitle()).to.eq('cdrApp.cashDrawerSession.delete.question');
    await cashDrawerSessionDeleteDialog.clickOnConfirmButton();

    expect(await cashDrawerSessionComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
