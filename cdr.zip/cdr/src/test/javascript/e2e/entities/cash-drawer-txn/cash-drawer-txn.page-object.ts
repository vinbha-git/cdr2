import { element, by, ElementFinder } from 'protractor';

export class CashDrawerTxnComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-cash-drawer-txn div table .btn-danger'));
  title = element.all(by.css('jhi-cash-drawer-txn div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getAttribute('jhiTranslate');
  }
}

export class CashDrawerTxnUpdatePage {
  pageTitle = element(by.id('jhi-cash-drawer-txn-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  txnDateInput = element(by.id('field_txnDate'));
  txnCodeSelect = element(by.id('field_txnCode'));
  txnStatusSelect = element(by.id('field_txnStatus'));
  txnAuthorisedUserCodeInput = element(by.id('field_txnAuthorisedUserCode'));
  txnAuthorisedDateInput = element(by.id('field_txnAuthorisedDate'));
  txnAuthorisedReasonInput = element(by.id('field_txnAuthorisedReason'));
  totalCoinAmtInput = element(by.id('field_totalCoinAmt'));
  totalNoteAmtInput = element(by.id('field_totalNoteAmt'));
  totalCheckAmtInput = element(by.id('field_totalCheckAmt'));
  totalPosAmtInput = element(by.id('field_totalPosAmt'));
  coinCent1RollInput = element(by.id('field_coinCent1Roll'));
  coinCent1LoseInput = element(by.id('field_coinCent1Lose'));
  coinCent5RollInput = element(by.id('field_coinCent5Roll'));
  coinCent5LooseInput = element(by.id('field_coinCent5Loose'));
  coinCent10RollInput = element(by.id('field_coinCent10Roll'));
  coinCent10LooseInput = element(by.id('field_coinCent10Loose'));
  coinCent25RollInput = element(by.id('field_coinCent25Roll'));
  coinCent25LooseInput = element(by.id('field_coinCent25Loose'));
  coinCent50RollInput = element(by.id('field_coinCent50Roll'));
  coinCent50LooseInput = element(by.id('field_coinCent50Loose'));
  coinDollar1RollInput = element(by.id('field_coinDollar1Roll'));
  coinDollar1LooseInput = element(by.id('field_coinDollar1Loose'));
  noteDollar1BundleInput = element(by.id('field_noteDollar1Bundle'));
  noteDollar1LooseInput = element(by.id('field_noteDollar1Loose'));
  noteDollar2BundleInput = element(by.id('field_noteDollar2Bundle'));
  noteDollar2LooseInput = element(by.id('field_noteDollar2Loose'));
  noteDollar5BundleInput = element(by.id('field_noteDollar5Bundle'));
  noteDollar5LooseInput = element(by.id('field_noteDollar5Loose'));
  noteDollar10BundleInput = element(by.id('field_noteDollar10Bundle'));
  noteDollar10LooseInput = element(by.id('field_noteDollar10Loose'));
  noteDollar20BundleInput = element(by.id('field_noteDollar20Bundle'));
  noteDollar20LooseInput = element(by.id('field_noteDollar20Loose'));
  noteDollar50BundleInput = element(by.id('field_noteDollar50Bundle'));
  noteDollar50LooseInput = element(by.id('field_noteDollar50Loose'));
  noteDollar100BundleInput = element(by.id('field_noteDollar100Bundle'));
  noteDollar100LooseInput = element(by.id('field_noteDollar100Loose'));
  createdByInput = element(by.id('field_createdBy'));
  creationDateInput = element(by.id('field_creationDate'));
  lastUpdatedByInput = element(by.id('field_lastUpdatedBy'));
  lastUpdateDateInput = element(by.id('field_lastUpdateDate'));

  cashDrawerSelect = element(by.id('field_cashDrawer'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getAttribute('jhiTranslate');
  }

  async setTxnDateInput(txnDate: string): Promise<void> {
    await this.txnDateInput.sendKeys(txnDate);
  }

  async getTxnDateInput(): Promise<string> {
    return await this.txnDateInput.getAttribute('value');
  }

  async setTxnCodeSelect(txnCode: string): Promise<void> {
    await this.txnCodeSelect.sendKeys(txnCode);
  }

  async getTxnCodeSelect(): Promise<string> {
    return await this.txnCodeSelect.element(by.css('option:checked')).getText();
  }

  async txnCodeSelectLastOption(): Promise<void> {
    await this.txnCodeSelect.all(by.tagName('option')).last().click();
  }

  async setTxnStatusSelect(txnStatus: string): Promise<void> {
    await this.txnStatusSelect.sendKeys(txnStatus);
  }

  async getTxnStatusSelect(): Promise<string> {
    return await this.txnStatusSelect.element(by.css('option:checked')).getText();
  }

  async txnStatusSelectLastOption(): Promise<void> {
    await this.txnStatusSelect.all(by.tagName('option')).last().click();
  }

  async setTxnAuthorisedUserCodeInput(txnAuthorisedUserCode: string): Promise<void> {
    await this.txnAuthorisedUserCodeInput.sendKeys(txnAuthorisedUserCode);
  }

  async getTxnAuthorisedUserCodeInput(): Promise<string> {
    return await this.txnAuthorisedUserCodeInput.getAttribute('value');
  }

  async setTxnAuthorisedDateInput(txnAuthorisedDate: string): Promise<void> {
    await this.txnAuthorisedDateInput.sendKeys(txnAuthorisedDate);
  }

  async getTxnAuthorisedDateInput(): Promise<string> {
    return await this.txnAuthorisedDateInput.getAttribute('value');
  }

  async setTxnAuthorisedReasonInput(txnAuthorisedReason: string): Promise<void> {
    await this.txnAuthorisedReasonInput.sendKeys(txnAuthorisedReason);
  }

  async getTxnAuthorisedReasonInput(): Promise<string> {
    return await this.txnAuthorisedReasonInput.getAttribute('value');
  }

  async setTotalCoinAmtInput(totalCoinAmt: string): Promise<void> {
    await this.totalCoinAmtInput.sendKeys(totalCoinAmt);
  }

  async getTotalCoinAmtInput(): Promise<string> {
    return await this.totalCoinAmtInput.getAttribute('value');
  }

  async setTotalNoteAmtInput(totalNoteAmt: string): Promise<void> {
    await this.totalNoteAmtInput.sendKeys(totalNoteAmt);
  }

  async getTotalNoteAmtInput(): Promise<string> {
    return await this.totalNoteAmtInput.getAttribute('value');
  }

  async setTotalCheckAmtInput(totalCheckAmt: string): Promise<void> {
    await this.totalCheckAmtInput.sendKeys(totalCheckAmt);
  }

  async getTotalCheckAmtInput(): Promise<string> {
    return await this.totalCheckAmtInput.getAttribute('value');
  }

  async setTotalPosAmtInput(totalPosAmt: string): Promise<void> {
    await this.totalPosAmtInput.sendKeys(totalPosAmt);
  }

  async getTotalPosAmtInput(): Promise<string> {
    return await this.totalPosAmtInput.getAttribute('value');
  }

  async setCoinCent1RollInput(coinCent1Roll: string): Promise<void> {
    await this.coinCent1RollInput.sendKeys(coinCent1Roll);
  }

  async getCoinCent1RollInput(): Promise<string> {
    return await this.coinCent1RollInput.getAttribute('value');
  }

  async setCoinCent1LoseInput(coinCent1Lose: string): Promise<void> {
    await this.coinCent1LoseInput.sendKeys(coinCent1Lose);
  }

  async getCoinCent1LoseInput(): Promise<string> {
    return await this.coinCent1LoseInput.getAttribute('value');
  }

  async setCoinCent5RollInput(coinCent5Roll: string): Promise<void> {
    await this.coinCent5RollInput.sendKeys(coinCent5Roll);
  }

  async getCoinCent5RollInput(): Promise<string> {
    return await this.coinCent5RollInput.getAttribute('value');
  }

  async setCoinCent5LooseInput(coinCent5Loose: string): Promise<void> {
    await this.coinCent5LooseInput.sendKeys(coinCent5Loose);
  }

  async getCoinCent5LooseInput(): Promise<string> {
    return await this.coinCent5LooseInput.getAttribute('value');
  }

  async setCoinCent10RollInput(coinCent10Roll: string): Promise<void> {
    await this.coinCent10RollInput.sendKeys(coinCent10Roll);
  }

  async getCoinCent10RollInput(): Promise<string> {
    return await this.coinCent10RollInput.getAttribute('value');
  }

  async setCoinCent10LooseInput(coinCent10Loose: string): Promise<void> {
    await this.coinCent10LooseInput.sendKeys(coinCent10Loose);
  }

  async getCoinCent10LooseInput(): Promise<string> {
    return await this.coinCent10LooseInput.getAttribute('value');
  }

  async setCoinCent25RollInput(coinCent25Roll: string): Promise<void> {
    await this.coinCent25RollInput.sendKeys(coinCent25Roll);
  }

  async getCoinCent25RollInput(): Promise<string> {
    return await this.coinCent25RollInput.getAttribute('value');
  }

  async setCoinCent25LooseInput(coinCent25Loose: string): Promise<void> {
    await this.coinCent25LooseInput.sendKeys(coinCent25Loose);
  }

  async getCoinCent25LooseInput(): Promise<string> {
    return await this.coinCent25LooseInput.getAttribute('value');
  }

  async setCoinCent50RollInput(coinCent50Roll: string): Promise<void> {
    await this.coinCent50RollInput.sendKeys(coinCent50Roll);
  }

  async getCoinCent50RollInput(): Promise<string> {
    return await this.coinCent50RollInput.getAttribute('value');
  }

  async setCoinCent50LooseInput(coinCent50Loose: string): Promise<void> {
    await this.coinCent50LooseInput.sendKeys(coinCent50Loose);
  }

  async getCoinCent50LooseInput(): Promise<string> {
    return await this.coinCent50LooseInput.getAttribute('value');
  }

  async setCoinDollar1RollInput(coinDollar1Roll: string): Promise<void> {
    await this.coinDollar1RollInput.sendKeys(coinDollar1Roll);
  }

  async getCoinDollar1RollInput(): Promise<string> {
    return await this.coinDollar1RollInput.getAttribute('value');
  }

  async setCoinDollar1LooseInput(coinDollar1Loose: string): Promise<void> {
    await this.coinDollar1LooseInput.sendKeys(coinDollar1Loose);
  }

  async getCoinDollar1LooseInput(): Promise<string> {
    return await this.coinDollar1LooseInput.getAttribute('value');
  }

  async setNoteDollar1BundleInput(noteDollar1Bundle: string): Promise<void> {
    await this.noteDollar1BundleInput.sendKeys(noteDollar1Bundle);
  }

  async getNoteDollar1BundleInput(): Promise<string> {
    return await this.noteDollar1BundleInput.getAttribute('value');
  }

  async setNoteDollar1LooseInput(noteDollar1Loose: string): Promise<void> {
    await this.noteDollar1LooseInput.sendKeys(noteDollar1Loose);
  }

  async getNoteDollar1LooseInput(): Promise<string> {
    return await this.noteDollar1LooseInput.getAttribute('value');
  }

  async setNoteDollar2BundleInput(noteDollar2Bundle: string): Promise<void> {
    await this.noteDollar2BundleInput.sendKeys(noteDollar2Bundle);
  }

  async getNoteDollar2BundleInput(): Promise<string> {
    return await this.noteDollar2BundleInput.getAttribute('value');
  }

  async setNoteDollar2LooseInput(noteDollar2Loose: string): Promise<void> {
    await this.noteDollar2LooseInput.sendKeys(noteDollar2Loose);
  }

  async getNoteDollar2LooseInput(): Promise<string> {
    return await this.noteDollar2LooseInput.getAttribute('value');
  }

  async setNoteDollar5BundleInput(noteDollar5Bundle: string): Promise<void> {
    await this.noteDollar5BundleInput.sendKeys(noteDollar5Bundle);
  }

  async getNoteDollar5BundleInput(): Promise<string> {
    return await this.noteDollar5BundleInput.getAttribute('value');
  }

  async setNoteDollar5LooseInput(noteDollar5Loose: string): Promise<void> {
    await this.noteDollar5LooseInput.sendKeys(noteDollar5Loose);
  }

  async getNoteDollar5LooseInput(): Promise<string> {
    return await this.noteDollar5LooseInput.getAttribute('value');
  }

  async setNoteDollar10BundleInput(noteDollar10Bundle: string): Promise<void> {
    await this.noteDollar10BundleInput.sendKeys(noteDollar10Bundle);
  }

  async getNoteDollar10BundleInput(): Promise<string> {
    return await this.noteDollar10BundleInput.getAttribute('value');
  }

  async setNoteDollar10LooseInput(noteDollar10Loose: string): Promise<void> {
    await this.noteDollar10LooseInput.sendKeys(noteDollar10Loose);
  }

  async getNoteDollar10LooseInput(): Promise<string> {
    return await this.noteDollar10LooseInput.getAttribute('value');
  }

  async setNoteDollar20BundleInput(noteDollar20Bundle: string): Promise<void> {
    await this.noteDollar20BundleInput.sendKeys(noteDollar20Bundle);
  }

  async getNoteDollar20BundleInput(): Promise<string> {
    return await this.noteDollar20BundleInput.getAttribute('value');
  }

  async setNoteDollar20LooseInput(noteDollar20Loose: string): Promise<void> {
    await this.noteDollar20LooseInput.sendKeys(noteDollar20Loose);
  }

  async getNoteDollar20LooseInput(): Promise<string> {
    return await this.noteDollar20LooseInput.getAttribute('value');
  }

  async setNoteDollar50BundleInput(noteDollar50Bundle: string): Promise<void> {
    await this.noteDollar50BundleInput.sendKeys(noteDollar50Bundle);
  }

  async getNoteDollar50BundleInput(): Promise<string> {
    return await this.noteDollar50BundleInput.getAttribute('value');
  }

  async setNoteDollar50LooseInput(noteDollar50Loose: string): Promise<void> {
    await this.noteDollar50LooseInput.sendKeys(noteDollar50Loose);
  }

  async getNoteDollar50LooseInput(): Promise<string> {
    return await this.noteDollar50LooseInput.getAttribute('value');
  }

  async setNoteDollar100BundleInput(noteDollar100Bundle: string): Promise<void> {
    await this.noteDollar100BundleInput.sendKeys(noteDollar100Bundle);
  }

  async getNoteDollar100BundleInput(): Promise<string> {
    return await this.noteDollar100BundleInput.getAttribute('value');
  }

  async setNoteDollar100LooseInput(noteDollar100Loose: string): Promise<void> {
    await this.noteDollar100LooseInput.sendKeys(noteDollar100Loose);
  }

  async getNoteDollar100LooseInput(): Promise<string> {
    return await this.noteDollar100LooseInput.getAttribute('value');
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setCreationDateInput(creationDate: string): Promise<void> {
    await this.creationDateInput.sendKeys(creationDate);
  }

  async getCreationDateInput(): Promise<string> {
    return await this.creationDateInput.getAttribute('value');
  }

  async setLastUpdatedByInput(lastUpdatedBy: string): Promise<void> {
    await this.lastUpdatedByInput.sendKeys(lastUpdatedBy);
  }

  async getLastUpdatedByInput(): Promise<string> {
    return await this.lastUpdatedByInput.getAttribute('value');
  }

  async setLastUpdateDateInput(lastUpdateDate: string): Promise<void> {
    await this.lastUpdateDateInput.sendKeys(lastUpdateDate);
  }

  async getLastUpdateDateInput(): Promise<string> {
    return await this.lastUpdateDateInput.getAttribute('value');
  }

  async cashDrawerSelectLastOption(): Promise<void> {
    await this.cashDrawerSelect.all(by.tagName('option')).last().click();
  }

  async cashDrawerSelectOption(option: string): Promise<void> {
    await this.cashDrawerSelect.sendKeys(option);
  }

  getCashDrawerSelect(): ElementFinder {
    return this.cashDrawerSelect;
  }

  async getCashDrawerSelectedOption(): Promise<string> {
    return await this.cashDrawerSelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class CashDrawerTxnDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-cashDrawerTxn-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-cashDrawerTxn'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getAttribute('jhiTranslate');
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
