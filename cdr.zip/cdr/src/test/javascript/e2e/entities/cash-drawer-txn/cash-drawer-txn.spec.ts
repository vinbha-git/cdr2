import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import { CashDrawerTxnComponentsPage, CashDrawerTxnDeleteDialog, CashDrawerTxnUpdatePage } from './cash-drawer-txn.page-object';

const expect = chai.expect;

describe('CashDrawerTxn e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let cashDrawerTxnComponentsPage: CashDrawerTxnComponentsPage;
  let cashDrawerTxnUpdatePage: CashDrawerTxnUpdatePage;
  let cashDrawerTxnDeleteDialog: CashDrawerTxnDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load CashDrawerTxns', async () => {
    await navBarPage.goToEntity('cash-drawer-txn');
    cashDrawerTxnComponentsPage = new CashDrawerTxnComponentsPage();
    await browser.wait(ec.visibilityOf(cashDrawerTxnComponentsPage.title), 5000);
    expect(await cashDrawerTxnComponentsPage.getTitle()).to.eq('cdrApp.cashDrawerTxn.home.title');
    await browser.wait(
      ec.or(ec.visibilityOf(cashDrawerTxnComponentsPage.entities), ec.visibilityOf(cashDrawerTxnComponentsPage.noResult)),
      1000
    );
  });

  it('should load create CashDrawerTxn page', async () => {
    await cashDrawerTxnComponentsPage.clickOnCreateButton();
    cashDrawerTxnUpdatePage = new CashDrawerTxnUpdatePage();
    expect(await cashDrawerTxnUpdatePage.getPageTitle()).to.eq('cdrApp.cashDrawerTxn.home.createOrEditLabel');
    await cashDrawerTxnUpdatePage.cancel();
  });

  it('should create and save CashDrawerTxns', async () => {
    const nbButtonsBeforeCreate = await cashDrawerTxnComponentsPage.countDeleteButtons();

    await cashDrawerTxnComponentsPage.clickOnCreateButton();

    await promise.all([
      cashDrawerTxnUpdatePage.setTxnDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnUpdatePage.txnCodeSelectLastOption(),
      cashDrawerTxnUpdatePage.txnStatusSelectLastOption(),
      cashDrawerTxnUpdatePage.setTxnAuthorisedUserCodeInput('txnAuthorisedUserCode'),
      cashDrawerTxnUpdatePage.setTxnAuthorisedDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnUpdatePage.setTxnAuthorisedReasonInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnUpdatePage.setTotalCoinAmtInput('5'),
      cashDrawerTxnUpdatePage.setTotalNoteAmtInput('5'),
      cashDrawerTxnUpdatePage.setTotalCheckAmtInput('5'),
      cashDrawerTxnUpdatePage.setTotalPosAmtInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent1RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent1LoseInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent5RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent5LooseInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent10RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent10LooseInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent25RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent25LooseInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent50RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinCent50LooseInput('5'),
      cashDrawerTxnUpdatePage.setCoinDollar1RollInput('5'),
      cashDrawerTxnUpdatePage.setCoinDollar1LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar1BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar1LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar2BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar2LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar5BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar5LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar10BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar10LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar20BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar20LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar50BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar50LooseInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar100BundleInput('5'),
      cashDrawerTxnUpdatePage.setNoteDollar100LooseInput('5'),
      cashDrawerTxnUpdatePage.setCreatedByInput('createdBy'),
      cashDrawerTxnUpdatePage.setCreationDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnUpdatePage.setLastUpdatedByInput('lastUpdatedBy'),
      cashDrawerTxnUpdatePage.setLastUpdateDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnUpdatePage.cashDrawerSelectLastOption(),
    ]);

    expect(await cashDrawerTxnUpdatePage.getTxnDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected txnDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerTxnUpdatePage.getTxnAuthorisedUserCodeInput()).to.eq(
      'txnAuthorisedUserCode',
      'Expected TxnAuthorisedUserCode value to be equals to txnAuthorisedUserCode'
    );
    expect(await cashDrawerTxnUpdatePage.getTxnAuthorisedDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected txnAuthorisedDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerTxnUpdatePage.getTxnAuthorisedReasonInput()).to.contain(
      '2001-01-01T02:30',
      'Expected txnAuthorisedReason value to be equals to 2000-12-31'
    );
    expect(await cashDrawerTxnUpdatePage.getTotalCoinAmtInput()).to.eq('5', 'Expected totalCoinAmt value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getTotalNoteAmtInput()).to.eq('5', 'Expected totalNoteAmt value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getTotalCheckAmtInput()).to.eq('5', 'Expected totalCheckAmt value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getTotalPosAmtInput()).to.eq('5', 'Expected totalPosAmt value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent1RollInput()).to.eq('5', 'Expected coinCent1Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent1LoseInput()).to.eq('5', 'Expected coinCent1Lose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent5RollInput()).to.eq('5', 'Expected coinCent5Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent5LooseInput()).to.eq('5', 'Expected coinCent5Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent10RollInput()).to.eq('5', 'Expected coinCent10Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent10LooseInput()).to.eq('5', 'Expected coinCent10Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent25RollInput()).to.eq('5', 'Expected coinCent25Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent25LooseInput()).to.eq('5', 'Expected coinCent25Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent50RollInput()).to.eq('5', 'Expected coinCent50Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinCent50LooseInput()).to.eq('5', 'Expected coinCent50Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinDollar1RollInput()).to.eq('5', 'Expected coinDollar1Roll value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCoinDollar1LooseInput()).to.eq('5', 'Expected coinDollar1Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar1BundleInput()).to.eq('5', 'Expected noteDollar1Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar1LooseInput()).to.eq('5', 'Expected noteDollar1Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar2BundleInput()).to.eq('5', 'Expected noteDollar2Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar2LooseInput()).to.eq('5', 'Expected noteDollar2Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar5BundleInput()).to.eq('5', 'Expected noteDollar5Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar5LooseInput()).to.eq('5', 'Expected noteDollar5Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar10BundleInput()).to.eq('5', 'Expected noteDollar10Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar10LooseInput()).to.eq('5', 'Expected noteDollar10Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar20BundleInput()).to.eq('5', 'Expected noteDollar20Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar20LooseInput()).to.eq('5', 'Expected noteDollar20Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar50BundleInput()).to.eq('5', 'Expected noteDollar50Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar50LooseInput()).to.eq('5', 'Expected noteDollar50Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar100BundleInput()).to.eq('5', 'Expected noteDollar100Bundle value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getNoteDollar100LooseInput()).to.eq('5', 'Expected noteDollar100Loose value to be equals to 5');
    expect(await cashDrawerTxnUpdatePage.getCreatedByInput()).to.eq('createdBy', 'Expected CreatedBy value to be equals to createdBy');
    expect(await cashDrawerTxnUpdatePage.getCreationDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected creationDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerTxnUpdatePage.getLastUpdatedByInput()).to.eq(
      'lastUpdatedBy',
      'Expected LastUpdatedBy value to be equals to lastUpdatedBy'
    );
    expect(await cashDrawerTxnUpdatePage.getLastUpdateDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected lastUpdateDate value to be equals to 2000-12-31'
    );

    await cashDrawerTxnUpdatePage.save();
    expect(await cashDrawerTxnUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await cashDrawerTxnComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeCreate + 1, 'Expected one more entry in the table');
  });

  it('should delete last CashDrawerTxn', async () => {
    const nbButtonsBeforeDelete = await cashDrawerTxnComponentsPage.countDeleteButtons();
    await cashDrawerTxnComponentsPage.clickOnLastDeleteButton();

    cashDrawerTxnDeleteDialog = new CashDrawerTxnDeleteDialog();
    expect(await cashDrawerTxnDeleteDialog.getDialogTitle()).to.eq('cdrApp.cashDrawerTxn.delete.question');
    await cashDrawerTxnDeleteDialog.clickOnConfirmButton();

    expect(await cashDrawerTxnComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
