import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import {
  CashDrawerTxnResultComponentsPage,
  CashDrawerTxnResultDeleteDialog,
  CashDrawerTxnResultUpdatePage,
} from './cash-drawer-txn-result.page-object';

const expect = chai.expect;

describe('CashDrawerTxnResult e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let cashDrawerTxnResultComponentsPage: CashDrawerTxnResultComponentsPage;
  let cashDrawerTxnResultUpdatePage: CashDrawerTxnResultUpdatePage;
  let cashDrawerTxnResultDeleteDialog: CashDrawerTxnResultDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load CashDrawerTxnResults', async () => {
    await navBarPage.goToEntity('cash-drawer-txn-result');
    cashDrawerTxnResultComponentsPage = new CashDrawerTxnResultComponentsPage();
    await browser.wait(ec.visibilityOf(cashDrawerTxnResultComponentsPage.title), 5000);
    expect(await cashDrawerTxnResultComponentsPage.getTitle()).to.eq('cdrApp.cashDrawerTxnResult.home.title');
    await browser.wait(
      ec.or(ec.visibilityOf(cashDrawerTxnResultComponentsPage.entities), ec.visibilityOf(cashDrawerTxnResultComponentsPage.noResult)),
      1000
    );
  });

  it('should load create CashDrawerTxnResult page', async () => {
    await cashDrawerTxnResultComponentsPage.clickOnCreateButton();
    cashDrawerTxnResultUpdatePage = new CashDrawerTxnResultUpdatePage();
    expect(await cashDrawerTxnResultUpdatePage.getPageTitle()).to.eq('cdrApp.cashDrawerTxnResult.home.createOrEditLabel');
    await cashDrawerTxnResultUpdatePage.cancel();
  });

  it('should create and save CashDrawerTxnResults', async () => {
    const nbButtonsBeforeCreate = await cashDrawerTxnResultComponentsPage.countDeleteButtons();

    await cashDrawerTxnResultComponentsPage.clickOnCreateButton();

    await promise.all([
      cashDrawerTxnResultUpdatePage.setSystemCashBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setSystemCheckBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setSystemPosBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setEnteredCashBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setEnteredCheckBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setEnteredPosBalanceInput('5'),
      cashDrawerTxnResultUpdatePage.setCreatedByInput('createdBy'),
      cashDrawerTxnResultUpdatePage.setCreationDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnResultUpdatePage.setLastUpdatedByInput('lastUpdatedBy'),
      cashDrawerTxnResultUpdatePage.setLastUpdateDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerTxnResultUpdatePage.cashDrawerTxnSelectLastOption(),
    ]);

    expect(await cashDrawerTxnResultUpdatePage.getSystemCashBalanceInput()).to.eq(
      '5',
      'Expected systemCashBalance value to be equals to 5'
    );
    expect(await cashDrawerTxnResultUpdatePage.getSystemCheckBalanceInput()).to.eq(
      '5',
      'Expected systemCheckBalance value to be equals to 5'
    );
    expect(await cashDrawerTxnResultUpdatePage.getSystemPosBalanceInput()).to.eq('5', 'Expected systemPosBalance value to be equals to 5');
    expect(await cashDrawerTxnResultUpdatePage.getEnteredCashBalanceInput()).to.eq(
      '5',
      'Expected enteredCashBalance value to be equals to 5'
    );
    expect(await cashDrawerTxnResultUpdatePage.getEnteredCheckBalanceInput()).to.eq(
      '5',
      'Expected enteredCheckBalance value to be equals to 5'
    );
    expect(await cashDrawerTxnResultUpdatePage.getEnteredPosBalanceInput()).to.eq(
      '5',
      'Expected enteredPosBalance value to be equals to 5'
    );
    expect(await cashDrawerTxnResultUpdatePage.getCreatedByInput()).to.eq(
      'createdBy',
      'Expected CreatedBy value to be equals to createdBy'
    );
    expect(await cashDrawerTxnResultUpdatePage.getCreationDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected creationDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerTxnResultUpdatePage.getLastUpdatedByInput()).to.eq(
      'lastUpdatedBy',
      'Expected LastUpdatedBy value to be equals to lastUpdatedBy'
    );
    expect(await cashDrawerTxnResultUpdatePage.getLastUpdateDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected lastUpdateDate value to be equals to 2000-12-31'
    );

    await cashDrawerTxnResultUpdatePage.save();
    expect(await cashDrawerTxnResultUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await cashDrawerTxnResultComponentsPage.countDeleteButtons()).to.eq(
      nbButtonsBeforeCreate + 1,
      'Expected one more entry in the table'
    );
  });

  it('should delete last CashDrawerTxnResult', async () => {
    const nbButtonsBeforeDelete = await cashDrawerTxnResultComponentsPage.countDeleteButtons();
    await cashDrawerTxnResultComponentsPage.clickOnLastDeleteButton();

    cashDrawerTxnResultDeleteDialog = new CashDrawerTxnResultDeleteDialog();
    expect(await cashDrawerTxnResultDeleteDialog.getDialogTitle()).to.eq('cdrApp.cashDrawerTxnResult.delete.question');
    await cashDrawerTxnResultDeleteDialog.clickOnConfirmButton();

    expect(await cashDrawerTxnResultComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
