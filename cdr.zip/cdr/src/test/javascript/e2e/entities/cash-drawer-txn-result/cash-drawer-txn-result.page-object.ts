import { element, by, ElementFinder } from 'protractor';

export class CashDrawerTxnResultComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-cash-drawer-txn-result div table .btn-danger'));
  title = element.all(by.css('jhi-cash-drawer-txn-result div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getAttribute('jhiTranslate');
  }
}

export class CashDrawerTxnResultUpdatePage {
  pageTitle = element(by.id('jhi-cash-drawer-txn-result-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  systemCashBalanceInput = element(by.id('field_systemCashBalance'));
  systemCheckBalanceInput = element(by.id('field_systemCheckBalance'));
  systemPosBalanceInput = element(by.id('field_systemPosBalance'));
  enteredCashBalanceInput = element(by.id('field_enteredCashBalance'));
  enteredCheckBalanceInput = element(by.id('field_enteredCheckBalance'));
  enteredPosBalanceInput = element(by.id('field_enteredPosBalance'));
  createdByInput = element(by.id('field_createdBy'));
  creationDateInput = element(by.id('field_creationDate'));
  lastUpdatedByInput = element(by.id('field_lastUpdatedBy'));
  lastUpdateDateInput = element(by.id('field_lastUpdateDate'));

  cashDrawerTxnSelect = element(by.id('field_cashDrawerTxn'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getAttribute('jhiTranslate');
  }

  async setSystemCashBalanceInput(systemCashBalance: string): Promise<void> {
    await this.systemCashBalanceInput.sendKeys(systemCashBalance);
  }

  async getSystemCashBalanceInput(): Promise<string> {
    return await this.systemCashBalanceInput.getAttribute('value');
  }

  async setSystemCheckBalanceInput(systemCheckBalance: string): Promise<void> {
    await this.systemCheckBalanceInput.sendKeys(systemCheckBalance);
  }

  async getSystemCheckBalanceInput(): Promise<string> {
    return await this.systemCheckBalanceInput.getAttribute('value');
  }

  async setSystemPosBalanceInput(systemPosBalance: string): Promise<void> {
    await this.systemPosBalanceInput.sendKeys(systemPosBalance);
  }

  async getSystemPosBalanceInput(): Promise<string> {
    return await this.systemPosBalanceInput.getAttribute('value');
  }

  async setEnteredCashBalanceInput(enteredCashBalance: string): Promise<void> {
    await this.enteredCashBalanceInput.sendKeys(enteredCashBalance);
  }

  async getEnteredCashBalanceInput(): Promise<string> {
    return await this.enteredCashBalanceInput.getAttribute('value');
  }

  async setEnteredCheckBalanceInput(enteredCheckBalance: string): Promise<void> {
    await this.enteredCheckBalanceInput.sendKeys(enteredCheckBalance);
  }

  async getEnteredCheckBalanceInput(): Promise<string> {
    return await this.enteredCheckBalanceInput.getAttribute('value');
  }

  async setEnteredPosBalanceInput(enteredPosBalance: string): Promise<void> {
    await this.enteredPosBalanceInput.sendKeys(enteredPosBalance);
  }

  async getEnteredPosBalanceInput(): Promise<string> {
    return await this.enteredPosBalanceInput.getAttribute('value');
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setCreationDateInput(creationDate: string): Promise<void> {
    await this.creationDateInput.sendKeys(creationDate);
  }

  async getCreationDateInput(): Promise<string> {
    return await this.creationDateInput.getAttribute('value');
  }

  async setLastUpdatedByInput(lastUpdatedBy: string): Promise<void> {
    await this.lastUpdatedByInput.sendKeys(lastUpdatedBy);
  }

  async getLastUpdatedByInput(): Promise<string> {
    return await this.lastUpdatedByInput.getAttribute('value');
  }

  async setLastUpdateDateInput(lastUpdateDate: string): Promise<void> {
    await this.lastUpdateDateInput.sendKeys(lastUpdateDate);
  }

  async getLastUpdateDateInput(): Promise<string> {
    return await this.lastUpdateDateInput.getAttribute('value');
  }

  async cashDrawerTxnSelectLastOption(): Promise<void> {
    await this.cashDrawerTxnSelect.all(by.tagName('option')).last().click();
  }

  async cashDrawerTxnSelectOption(option: string): Promise<void> {
    await this.cashDrawerTxnSelect.sendKeys(option);
  }

  getCashDrawerTxnSelect(): ElementFinder {
    return this.cashDrawerTxnSelect;
  }

  async getCashDrawerTxnSelectedOption(): Promise<string> {
    return await this.cashDrawerTxnSelect.element(by.css('option:checked')).getText();
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class CashDrawerTxnResultDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-cashDrawerTxnResult-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-cashDrawerTxnResult'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getAttribute('jhiTranslate');
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
