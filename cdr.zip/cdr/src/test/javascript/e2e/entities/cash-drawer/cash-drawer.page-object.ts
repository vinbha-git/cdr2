import { element, by, ElementFinder } from 'protractor';

export class CashDrawerComponentsPage {
  createButton = element(by.id('jh-create-entity'));
  deleteButtons = element.all(by.css('jhi-cash-drawer div table .btn-danger'));
  title = element.all(by.css('jhi-cash-drawer div h2#page-heading span')).first();
  noResult = element(by.id('no-result'));
  entities = element(by.id('entities'));

  async clickOnCreateButton(): Promise<void> {
    await this.createButton.click();
  }

  async clickOnLastDeleteButton(): Promise<void> {
    await this.deleteButtons.last().click();
  }

  async countDeleteButtons(): Promise<number> {
    return this.deleteButtons.count();
  }

  async getTitle(): Promise<string> {
    return this.title.getAttribute('jhiTranslate');
  }
}

export class CashDrawerUpdatePage {
  pageTitle = element(by.id('jhi-cash-drawer-heading'));
  saveButton = element(by.id('save-entity'));
  cancelButton = element(by.id('cancel-save'));

  codeInput = element(by.id('field_code'));
  companyInput = element(by.id('field_company'));
  branchInput = element(by.id('field_branch'));
  statusSelect = element(by.id('field_status'));
  cashierUsrCodeInput = element(by.id('field_cashierUsrCode'));
  cashBalanceInput = element(by.id('field_cashBalance'));
  checkBalanceInput = element(by.id('field_checkBalance'));
  posBalanceInput = element(by.id('field_posBalance'));
  cashLimitInput = element(by.id('field_cashLimit'));
  changeLimitInput = element(by.id('field_changeLimit'));
  mainIndicatorInput = element(by.id('field_mainIndicator'));
  createdByInput = element(by.id('field_createdBy'));
  creationDateInput = element(by.id('field_creationDate'));
  lastUpdatedByInput = element(by.id('field_lastUpdatedBy'));
  lastUpdateDateInput = element(by.id('field_lastUpdateDate'));

  async getPageTitle(): Promise<string> {
    return this.pageTitle.getAttribute('jhiTranslate');
  }

  async setCodeInput(code: string): Promise<void> {
    await this.codeInput.sendKeys(code);
  }

  async getCodeInput(): Promise<string> {
    return await this.codeInput.getAttribute('value');
  }

  async setCompanyInput(company: string): Promise<void> {
    await this.companyInput.sendKeys(company);
  }

  async getCompanyInput(): Promise<string> {
    return await this.companyInput.getAttribute('value');
  }

  async setBranchInput(branch: string): Promise<void> {
    await this.branchInput.sendKeys(branch);
  }

  async getBranchInput(): Promise<string> {
    return await this.branchInput.getAttribute('value');
  }

  async setStatusSelect(status: string): Promise<void> {
    await this.statusSelect.sendKeys(status);
  }

  async getStatusSelect(): Promise<string> {
    return await this.statusSelect.element(by.css('option:checked')).getText();
  }

  async statusSelectLastOption(): Promise<void> {
    await this.statusSelect.all(by.tagName('option')).last().click();
  }

  async setCashierUsrCodeInput(cashierUsrCode: string): Promise<void> {
    await this.cashierUsrCodeInput.sendKeys(cashierUsrCode);
  }

  async getCashierUsrCodeInput(): Promise<string> {
    return await this.cashierUsrCodeInput.getAttribute('value');
  }

  async setCashBalanceInput(cashBalance: string): Promise<void> {
    await this.cashBalanceInput.sendKeys(cashBalance);
  }

  async getCashBalanceInput(): Promise<string> {
    return await this.cashBalanceInput.getAttribute('value');
  }

  async setCheckBalanceInput(checkBalance: string): Promise<void> {
    await this.checkBalanceInput.sendKeys(checkBalance);
  }

  async getCheckBalanceInput(): Promise<string> {
    return await this.checkBalanceInput.getAttribute('value');
  }

  async setPosBalanceInput(posBalance: string): Promise<void> {
    await this.posBalanceInput.sendKeys(posBalance);
  }

  async getPosBalanceInput(): Promise<string> {
    return await this.posBalanceInput.getAttribute('value');
  }

  async setCashLimitInput(cashLimit: string): Promise<void> {
    await this.cashLimitInput.sendKeys(cashLimit);
  }

  async getCashLimitInput(): Promise<string> {
    return await this.cashLimitInput.getAttribute('value');
  }

  async setChangeLimitInput(changeLimit: string): Promise<void> {
    await this.changeLimitInput.sendKeys(changeLimit);
  }

  async getChangeLimitInput(): Promise<string> {
    return await this.changeLimitInput.getAttribute('value');
  }

  getMainIndicatorInput(): ElementFinder {
    return this.mainIndicatorInput;
  }

  async setCreatedByInput(createdBy: string): Promise<void> {
    await this.createdByInput.sendKeys(createdBy);
  }

  async getCreatedByInput(): Promise<string> {
    return await this.createdByInput.getAttribute('value');
  }

  async setCreationDateInput(creationDate: string): Promise<void> {
    await this.creationDateInput.sendKeys(creationDate);
  }

  async getCreationDateInput(): Promise<string> {
    return await this.creationDateInput.getAttribute('value');
  }

  async setLastUpdatedByInput(lastUpdatedBy: string): Promise<void> {
    await this.lastUpdatedByInput.sendKeys(lastUpdatedBy);
  }

  async getLastUpdatedByInput(): Promise<string> {
    return await this.lastUpdatedByInput.getAttribute('value');
  }

  async setLastUpdateDateInput(lastUpdateDate: string): Promise<void> {
    await this.lastUpdateDateInput.sendKeys(lastUpdateDate);
  }

  async getLastUpdateDateInput(): Promise<string> {
    return await this.lastUpdateDateInput.getAttribute('value');
  }

  async save(): Promise<void> {
    await this.saveButton.click();
  }

  async cancel(): Promise<void> {
    await this.cancelButton.click();
  }

  getSaveButton(): ElementFinder {
    return this.saveButton;
  }
}

export class CashDrawerDeleteDialog {
  private dialogTitle = element(by.id('jhi-delete-cashDrawer-heading'));
  private confirmButton = element(by.id('jhi-confirm-delete-cashDrawer'));

  async getDialogTitle(): Promise<string> {
    return this.dialogTitle.getAttribute('jhiTranslate');
  }

  async clickOnConfirmButton(): Promise<void> {
    await this.confirmButton.click();
  }
}
