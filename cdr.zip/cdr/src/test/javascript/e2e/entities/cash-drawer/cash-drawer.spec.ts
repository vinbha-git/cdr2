import { browser, ExpectedConditions as ec, protractor, promise } from 'protractor';
import { NavBarPage, SignInPage } from '../../page-objects/jhi-page-objects';

import { CashDrawerComponentsPage, CashDrawerDeleteDialog, CashDrawerUpdatePage } from './cash-drawer.page-object';

const expect = chai.expect;

describe('CashDrawer e2e test', () => {
  let navBarPage: NavBarPage;
  let signInPage: SignInPage;
  let cashDrawerComponentsPage: CashDrawerComponentsPage;
  let cashDrawerUpdatePage: CashDrawerUpdatePage;
  let cashDrawerDeleteDialog: CashDrawerDeleteDialog;

  before(async () => {
    await browser.get('/');
    navBarPage = new NavBarPage();
    signInPage = await navBarPage.getSignInPage();
    await signInPage.autoSignInUsing('admin', 'admin');
    await browser.wait(ec.visibilityOf(navBarPage.entityMenu), 5000);
  });

  it('should load CashDrawers', async () => {
    await navBarPage.goToEntity('cash-drawer');
    cashDrawerComponentsPage = new CashDrawerComponentsPage();
    await browser.wait(ec.visibilityOf(cashDrawerComponentsPage.title), 5000);
    expect(await cashDrawerComponentsPage.getTitle()).to.eq('cdrApp.cashDrawer.home.title');
    await browser.wait(ec.or(ec.visibilityOf(cashDrawerComponentsPage.entities), ec.visibilityOf(cashDrawerComponentsPage.noResult)), 1000);
  });

  it('should load create CashDrawer page', async () => {
    await cashDrawerComponentsPage.clickOnCreateButton();
    cashDrawerUpdatePage = new CashDrawerUpdatePage();
    expect(await cashDrawerUpdatePage.getPageTitle()).to.eq('cdrApp.cashDrawer.home.createOrEditLabel');
    await cashDrawerUpdatePage.cancel();
  });

  it('should create and save CashDrawers', async () => {
    const nbButtonsBeforeCreate = await cashDrawerComponentsPage.countDeleteButtons();

    await cashDrawerComponentsPage.clickOnCreateButton();

    await promise.all([
      cashDrawerUpdatePage.setCodeInput('code'),
      cashDrawerUpdatePage.setCompanyInput('company'),
      cashDrawerUpdatePage.setBranchInput('branch'),
      cashDrawerUpdatePage.statusSelectLastOption(),
      cashDrawerUpdatePage.setCashierUsrCodeInput('cashierUsrCode'),
      cashDrawerUpdatePage.setCashBalanceInput('5'),
      cashDrawerUpdatePage.setCheckBalanceInput('5'),
      cashDrawerUpdatePage.setPosBalanceInput('5'),
      cashDrawerUpdatePage.setCashLimitInput('5'),
      cashDrawerUpdatePage.setChangeLimitInput('5'),
      cashDrawerUpdatePage.setCreatedByInput('createdBy'),
      cashDrawerUpdatePage.setCreationDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
      cashDrawerUpdatePage.setLastUpdatedByInput('lastUpdatedBy'),
      cashDrawerUpdatePage.setLastUpdateDateInput('01/01/2001' + protractor.Key.TAB + '02:30AM'),
    ]);

    expect(await cashDrawerUpdatePage.getCodeInput()).to.eq('code', 'Expected Code value to be equals to code');
    expect(await cashDrawerUpdatePage.getCompanyInput()).to.eq('company', 'Expected Company value to be equals to company');
    expect(await cashDrawerUpdatePage.getBranchInput()).to.eq('branch', 'Expected Branch value to be equals to branch');
    expect(await cashDrawerUpdatePage.getCashierUsrCodeInput()).to.eq(
      'cashierUsrCode',
      'Expected CashierUsrCode value to be equals to cashierUsrCode'
    );
    expect(await cashDrawerUpdatePage.getCashBalanceInput()).to.eq('5', 'Expected cashBalance value to be equals to 5');
    expect(await cashDrawerUpdatePage.getCheckBalanceInput()).to.eq('5', 'Expected checkBalance value to be equals to 5');
    expect(await cashDrawerUpdatePage.getPosBalanceInput()).to.eq('5', 'Expected posBalance value to be equals to 5');
    expect(await cashDrawerUpdatePage.getCashLimitInput()).to.eq('5', 'Expected cashLimit value to be equals to 5');
    expect(await cashDrawerUpdatePage.getChangeLimitInput()).to.eq('5', 'Expected changeLimit value to be equals to 5');
    const selectedMainIndicator = cashDrawerUpdatePage.getMainIndicatorInput();
    if (await selectedMainIndicator.isSelected()) {
      await cashDrawerUpdatePage.getMainIndicatorInput().click();
      expect(await cashDrawerUpdatePage.getMainIndicatorInput().isSelected(), 'Expected mainIndicator not to be selected').to.be.false;
    } else {
      await cashDrawerUpdatePage.getMainIndicatorInput().click();
      expect(await cashDrawerUpdatePage.getMainIndicatorInput().isSelected(), 'Expected mainIndicator to be selected').to.be.true;
    }
    expect(await cashDrawerUpdatePage.getCreatedByInput()).to.eq('createdBy', 'Expected CreatedBy value to be equals to createdBy');
    expect(await cashDrawerUpdatePage.getCreationDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected creationDate value to be equals to 2000-12-31'
    );
    expect(await cashDrawerUpdatePage.getLastUpdatedByInput()).to.eq(
      'lastUpdatedBy',
      'Expected LastUpdatedBy value to be equals to lastUpdatedBy'
    );
    expect(await cashDrawerUpdatePage.getLastUpdateDateInput()).to.contain(
      '2001-01-01T02:30',
      'Expected lastUpdateDate value to be equals to 2000-12-31'
    );

    await cashDrawerUpdatePage.save();
    expect(await cashDrawerUpdatePage.getSaveButton().isPresent(), 'Expected save button disappear').to.be.false;

    expect(await cashDrawerComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeCreate + 1, 'Expected one more entry in the table');
  });

  it('should delete last CashDrawer', async () => {
    const nbButtonsBeforeDelete = await cashDrawerComponentsPage.countDeleteButtons();
    await cashDrawerComponentsPage.clickOnLastDeleteButton();

    cashDrawerDeleteDialog = new CashDrawerDeleteDialog();
    expect(await cashDrawerDeleteDialog.getDialogTitle()).to.eq('cdrApp.cashDrawer.delete.question');
    await cashDrawerDeleteDialog.clickOnConfirmButton();

    expect(await cashDrawerComponentsPage.countDeleteButtons()).to.eq(nbButtonsBeforeDelete - 1);
  });

  after(async () => {
    await navBarPage.autoSignOut();
  });
});
