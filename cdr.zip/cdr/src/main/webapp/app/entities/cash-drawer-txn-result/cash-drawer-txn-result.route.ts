import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawerTxnResult, CashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';
import { CashDrawerTxnResultService } from './cash-drawer-txn-result.service';
import { CashDrawerTxnResultComponent } from './cash-drawer-txn-result.component';
import { CashDrawerTxnResultDetailComponent } from './cash-drawer-txn-result-detail.component';
import { CashDrawerTxnResultUpdateComponent } from './cash-drawer-txn-result-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerTxnResultResolve implements Resolve<ICashDrawerTxnResult> {
  constructor(private service: CashDrawerTxnResultService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawerTxnResult> | Observable<never> {
    const id = route.params['idr'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawerTxnResult: HttpResponse<CashDrawerTxnResult>) => {
          if (cashDrawerTxnResult.body) {
            return of(cashDrawerTxnResult.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawerTxnResult());
  }
}

export const cashDrawerTxnResultRoute: Routes = [
  {
    path: 'result',
    component: CashDrawerTxnResultComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
      title: 'Home / CashDrawerTxn / Results',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idr/viewresult',
    component: CashDrawerTxnResultDetailComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
      title: 'Home / CashDrawerTxn / Results / View',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'newresult',
    component: CashDrawerTxnResultUpdateComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
      title: 'Home / CashDrawerTxn / Results / New',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idr/editresult',
    component: CashDrawerTxnResultUpdateComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
      title: 'Home / CashDrawerTxn / Results / Edit',
    },
    canActivate: [UserRouteAccessService],
  },
];
