import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';
import { CashDrawerTxnResultService } from './cash-drawer-txn-result.service';
import { CashDrawerTxnResultDeleteDialogComponent } from './cash-drawer-txn-result-delete-dialog.component';

import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';

@Component({
  selector: 'jhi-cash-drawer-txn-result',
  templateUrl: './cash-drawer-txn-result.component.html',
})
export class CashDrawerTxnResultComponent implements OnInit, OnDestroy {
  cashDrawerTxnResults?: ICashDrawerTxnResult[];
  eventSubscriber?: Subscription;
  currentSearch: string;
  cashDrawerTxn?: ICashDrawerTxn;

  constructor(
    protected cashDrawerTxnResultService: CashDrawerTxnResultService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal,
    protected activatedRoute: ActivatedRoute
  ) {
    this.currentSearch =
      this.activatedRoute.snapshot && this.activatedRoute.snapshot.queryParams['search']
        ? this.activatedRoute.snapshot.queryParams['search']
        : '';
  }

  loadAll(): void {
    if (this.currentSearch) {
      this.cashDrawerTxnResultService
        .search({
          query: this.currentSearch,
        })
        .subscribe((res: HttpResponse<ICashDrawerTxnResult[]>) => (this.cashDrawerTxnResults = res.body || []));
      return;
    }

    this.cashDrawerTxnResultService
     .queryByCashDrawerTxn(Number(this.cashDrawerTxn?.id))
      .subscribe((res: HttpResponse<ICashDrawerTxnResult[]>) => (this.cashDrawerTxnResults = res.body || []));
  }

  search(query: string): void {
    this.currentSearch = query;
    this.loadAll();
  }

  ngOnInit(): void {
   this.activatedRoute.data.subscribe(({ cashDrawerTxn }) => { this.cashDrawerTxn = cashDrawerTxn; });
    this.loadAll();
    this.registerChangeInCashDrawerTxnResults();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: ICashDrawerTxnResult): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInCashDrawerTxnResults(): void {
    this.eventSubscriber = this.eventManager.subscribe('cashDrawerTxnResultListModification', () => this.loadAll());
  }

  delete(cashDrawerTxnResult: ICashDrawerTxnResult): void {
    const modalRef = this.modalService.open(CashDrawerTxnResultDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.cashDrawerTxnResult = cashDrawerTxnResult;
  }
}
