import { LocalStorageService } from 'ngx-webstorage';
import { NgbTabChangeEvent } from "@ng-bootstrap/ng-bootstrap"
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';

@Component({
  selector: 'jhi-cash-drawer-txn-detail',
  templateUrl: './cash-drawer-txn-detail.component.html',
})
export class CashDrawerTxnDetailComponent implements OnInit {
  cashDrawerTxn: ICashDrawerTxn | null = null;

    public activeTab: any;
    constructor(protected activatedRoute: ActivatedRoute,protected lStorageService: LocalStorageService) {}

  ngOnInit(): void {
    const temp = this.lStorageService.retrieve("activeTab");
    if (temp !== null && temp !== undefined){ this.activeTab = temp }
    this.activatedRoute.data.subscribe(({ cashDrawerTxn }) => (this.cashDrawerTxn = cashDrawerTxn));
  }

   beforeChange($event: NgbTabChangeEvent): void {
   this.activeTab = $event.nextId;
   // const state=window.history.state;
   // state['tabId']=this.activeTab;
   this.lStorageService.store("activeTab", this.activeTab);
   }

  previousState(): void {
    window.history.back();
  }
}
