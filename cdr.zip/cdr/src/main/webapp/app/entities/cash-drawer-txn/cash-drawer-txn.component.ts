import { LocalStorageService } from 'ngx-webstorage';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { CashDrawerTxnService } from './cash-drawer-txn.service';
import { CashDrawerTxnDeleteDialogComponent } from './cash-drawer-txn-delete-dialog.component';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';

@Component({
  selector: 'jhi-cash-drawer-txn',
  templateUrl: './cash-drawer-txn.component.html',
})
export class CashDrawerTxnComponent implements OnInit, OnDestroy {
  cashDrawerTxns?: ICashDrawerTxn[];
  eventSubscriber?: Subscription;
  currentSearch: string;
  cashDrawer?: ICashDrawer;

  constructor(
    protected lStorageService: LocalStorageService,
    protected cashDrawerTxnService: CashDrawerTxnService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal,
    protected activatedRoute: ActivatedRoute
  ) {
    this.currentSearch =
      this.activatedRoute.snapshot && this.activatedRoute.snapshot.queryParams['search']
        ? this.activatedRoute.snapshot.queryParams['search']
        : '';
  }

  loadAll(): void {
    if (this.currentSearch) {
      this.cashDrawerTxnService
        .search({
          query: this.currentSearch,
        })
        .subscribe((res: HttpResponse<ICashDrawerTxn[]>) => (this.cashDrawerTxns = res.body || []));
      return;
    }

     this.cashDrawerTxnService.queryByCashDrawer(Number(this.cashDrawer?.id)).subscribe((res: HttpResponse<ICashDrawerTxn[]>) => (this.cashDrawerTxns = res.body || []));
  }

  search(query: string): void {
    this.currentSearch = query;
    this.loadAll();
  }

  ngOnInit(): void {
   this.activatedRoute.data.subscribe(({ cashDrawer }) => { this.cashDrawer = cashDrawer; });
    const temp = this.lStorageService.retrieve("activeTab");
    if (temp !== null && temp !== undefined){ this.lStorageService.clear("activeTab"); }
    this.loadAll();
    this.registerChangeInCashDrawerTxns();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: ICashDrawerTxn): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInCashDrawerTxns(): void {
    this.eventSubscriber = this.eventManager.subscribe('cashDrawerTxnListModification', () => this.loadAll());
  }

  delete(cashDrawerTxn: ICashDrawerTxn): void {
    const modalRef = this.modalService.open(CashDrawerTxnDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.cashDrawerTxn = cashDrawerTxn;
  }
}
