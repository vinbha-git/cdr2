import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CdrSharedModule } from 'app/shared/shared.module';
import { CashDrawerTxnComponent } from './cash-drawer-txn.component';
import { CashDrawerTxnDetailComponent } from './cash-drawer-txn-detail.component';
import { CashDrawerTxnUpdateComponent } from './cash-drawer-txn-update.component';
import { CashDrawerTxnDeleteDialogComponent } from './cash-drawer-txn-delete-dialog.component';
import { cashDrawerTxnRoute } from './cash-drawer-txn.route';

import { CdrCashDrawerTxnResultModule } from '../cash-drawer-txn-result/cash-drawer-txn-result.module';
@NgModule({
  imports: [      CdrCashDrawerTxnResultModule,
CdrSharedModule, RouterModule.forChild(cashDrawerTxnRoute)],
  declarations: [CashDrawerTxnComponent, CashDrawerTxnDetailComponent, CashDrawerTxnUpdateComponent, CashDrawerTxnDeleteDialogComponent],
  entryComponents: [CashDrawerTxnDeleteDialogComponent],
  exports: [CashDrawerTxnComponent],
})
export class CdrCashDrawerTxnModule {}
