import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawerTxn, CashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { CashDrawerTxnService } from './cash-drawer-txn.service';
import { CashDrawerTxnComponent } from './cash-drawer-txn.component';
import { CashDrawerTxnDetailComponent } from './cash-drawer-txn-detail.component';
import { CashDrawerTxnUpdateComponent } from './cash-drawer-txn-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerTxnResolve implements Resolve<ICashDrawerTxn> {
  constructor(private service: CashDrawerTxnService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawerTxn> | Observable<never> {
    const id = route.params['idt'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawerTxn: HttpResponse<CashDrawerTxn>) => {
          if (cashDrawerTxn.body) {
            return of(cashDrawerTxn.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawerTxn());
  }
}

export const cashDrawerTxnRoute: Routes = [
  {
    path: 'txn',
    component: CashDrawerTxnComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxn.home.title',
      title: 'Home / CashDrawer / Txns',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idt/viewtxn',
    component: CashDrawerTxnDetailComponent,
    resolve: {
      cashDrawerTxn: CashDrawerTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxn.home.title',
      title: 'Home / CashDrawer / Txns / View',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'newtxn',
    component: CashDrawerTxnUpdateComponent,
    resolve: {
      cashDrawerTxn: CashDrawerTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxn.home.title',
      title: 'Home / CashDrawer / Txns / New',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idt/edittxn',
    component: CashDrawerTxnUpdateComponent,
    resolve: {
      cashDrawerTxn: CashDrawerTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxn.home.title',
      title: 'Home / CashDrawer / Txns / Edit',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idt/cash-drawer-txn-result',
    loadChildren: () => import('../cash-drawer-txn-result/cash-drawer-txn-result.module').then(m => m.CdrCashDrawerTxnResultModule),
  },
];
