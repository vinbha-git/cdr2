import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { map } from 'rxjs/operators';
import { AccountService } from 'app/core/auth/account.service';
import { Account } from 'app/core/user/account.model';

import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { ICashDrawerTxn, CashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { CashDrawerTxnService } from './cash-drawer-txn.service';
import { ICashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from 'app/entities/cash-drawer/cash-drawer.service';

@Component({
  selector: 'jhi-cash-drawer-txn-update',
  templateUrl: './cash-drawer-txn-update.component.html',
})
export class CashDrawerTxnUpdateComponent implements OnInit {
  isSaving = false;
  cashDrawer: ICashDrawer | null = null;
  account: Account | null = null;
  authSubscription?: Subscription;
  cashdrawers: ICashDrawer[] = [];

  editForm = this.fb.group({
    id: [],
    txnDate: [null, [Validators.required]],
    txnCode: [],
    txnStatus: [],
    txnAuthorisedUserCode: [],
    txnAuthorisedDate: [],
    txnAuthorisedReason: [],
    totalCoinAmt: [null, [Validators.required]],
    totalNoteAmt: [null, [Validators.required]],
    totalCheckAmt: [null, [Validators.required]],
    totalPosAmt: [null, [Validators.required]],
    coinCent1Roll: [null, [Validators.required]],
    coinCent1Lose: [null, [Validators.required]],
    coinCent5Roll: [null, [Validators.required]],
    coinCent5Loose: [null, [Validators.required]],
    coinCent10Roll: [null, [Validators.required]],
    coinCent10Loose: [null, [Validators.required]],
    coinCent25Roll: [null, [Validators.required]],
    coinCent25Loose: [null, [Validators.required]],
    coinCent50Roll: [null, [Validators.required]],
    coinCent50Loose: [null, [Validators.required]],
    coinDollar1Roll: [null, [Validators.required]],
    coinDollar1Loose: [null, [Validators.required]],
    noteDollar1Bundle: [null, [Validators.required]],
    noteDollar1Loose: [null, [Validators.required]],
    noteDollar2Bundle: [null, [Validators.required]],
    noteDollar2Loose: [null, [Validators.required]],
    noteDollar5Bundle: [null, [Validators.required]],
    noteDollar5Loose: [null, [Validators.required]],
    noteDollar10Bundle: [null, [Validators.required]],
    noteDollar10Loose: [null, [Validators.required]],
    noteDollar20Bundle: [null, [Validators.required]],
    noteDollar20Loose: [null, [Validators.required]],
    noteDollar50Bundle: [null, [Validators.required]],
    noteDollar50Loose: [null, [Validators.required]],
    noteDollar100Bundle: [null, [Validators.required]],
    noteDollar100Loose: [null, [Validators.required]],
    createdBy: [],
    creationDate: [],
    lastUpdatedBy: [],
    lastUpdateDate: [],
    cashDrawer: [],
  });

  constructor(
    protected cashDrawerTxnService: CashDrawerTxnService,
    protected cashDrawerService: CashDrawerService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
   ,protected accountService: AccountService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerTxn }) => {
     this.authSubscription = this.accountService.getAuthenticationState().subscribe(account => (this.account = account));
      if (!cashDrawerTxn.id) {
        const today = moment().startOf('day');
        cashDrawerTxn.txnDate = today;
        cashDrawerTxn.txnAuthorisedDate = today;
        cashDrawerTxn.txnAuthorisedReason = today;
        cashDrawerTxn.creationDate = today;
        cashDrawerTxn.lastUpdateDate = today;
        cashDrawerTxn.createdBy = this.account?.login;
        cashDrawerTxn.lastUpdatedBy = this.account?.login;
        this.activatedRoute.parent?.params.subscribe(params => {
          this.cashDrawerService.find(params['id']).subscribe((res1: HttpResponse<ICashDrawer>) => {
            this.cashDrawer = res1.body;
            cashDrawerTxn.cashDrawer = this.cashDrawer;
            this.updateForm(cashDrawerTxn);
          });
        });
      } else {
        const today = moment().startOf('day');
        cashDrawerTxn.lastUpdateDate = today;
        cashDrawerTxn.lastUpdatedBy = this.account?.login;
        this.updateForm(cashDrawerTxn);
      }


      this.cashDrawerService
        .query({ filter: 'cashdrawertxn-is-null' })
        .pipe(
          map((res: HttpResponse<ICashDrawer[]>) => {
            return res.body || [];
          })
        )
        .subscribe((resBody: ICashDrawer[]) => {
          if (!cashDrawerTxn.cashDrawer || !cashDrawerTxn.cashDrawer.id) {
            this.cashdrawers = resBody;
          } else {
            this.cashDrawerService
              .find(cashDrawerTxn.cashDrawer.id)
              .pipe(
                map((subRes: HttpResponse<ICashDrawer>) => {
                  return subRes.body ? [subRes.body].concat(resBody) : resBody;
                })
              )
              .subscribe((concatRes: ICashDrawer[]) => (this.cashdrawers = concatRes));
          }
        });
    });
  }

  updateForm(cashDrawerTxn: ICashDrawerTxn): void {
    this.editForm.patchValue({
      id: cashDrawerTxn.id,
      txnDate: cashDrawerTxn.txnDate ? cashDrawerTxn.txnDate.format(DATE_TIME_FORMAT) : null,
      txnCode: cashDrawerTxn.txnCode,
      txnStatus: cashDrawerTxn.txnStatus,
      txnAuthorisedUserCode: cashDrawerTxn.txnAuthorisedUserCode,
      txnAuthorisedDate: cashDrawerTxn.txnAuthorisedDate ? cashDrawerTxn.txnAuthorisedDate.format(DATE_TIME_FORMAT) : null,
      txnAuthorisedReason: cashDrawerTxn.txnAuthorisedReason ? cashDrawerTxn.txnAuthorisedReason.format(DATE_TIME_FORMAT) : null,
      totalCoinAmt: cashDrawerTxn.totalCoinAmt,
      totalNoteAmt: cashDrawerTxn.totalNoteAmt,
      totalCheckAmt: cashDrawerTxn.totalCheckAmt,
      totalPosAmt: cashDrawerTxn.totalPosAmt,
      coinCent1Roll: cashDrawerTxn.coinCent1Roll,
      coinCent1Lose: cashDrawerTxn.coinCent1Lose,
      coinCent5Roll: cashDrawerTxn.coinCent5Roll,
      coinCent5Loose: cashDrawerTxn.coinCent5Loose,
      coinCent10Roll: cashDrawerTxn.coinCent10Roll,
      coinCent10Loose: cashDrawerTxn.coinCent10Loose,
      coinCent25Roll: cashDrawerTxn.coinCent25Roll,
      coinCent25Loose: cashDrawerTxn.coinCent25Loose,
      coinCent50Roll: cashDrawerTxn.coinCent50Roll,
      coinCent50Loose: cashDrawerTxn.coinCent50Loose,
      coinDollar1Roll: cashDrawerTxn.coinDollar1Roll,
      coinDollar1Loose: cashDrawerTxn.coinDollar1Loose,
      noteDollar1Bundle: cashDrawerTxn.noteDollar1Bundle,
      noteDollar1Loose: cashDrawerTxn.noteDollar1Loose,
      noteDollar2Bundle: cashDrawerTxn.noteDollar2Bundle,
      noteDollar2Loose: cashDrawerTxn.noteDollar2Loose,
      noteDollar5Bundle: cashDrawerTxn.noteDollar5Bundle,
      noteDollar5Loose: cashDrawerTxn.noteDollar5Loose,
      noteDollar10Bundle: cashDrawerTxn.noteDollar10Bundle,
      noteDollar10Loose: cashDrawerTxn.noteDollar10Loose,
      noteDollar20Bundle: cashDrawerTxn.noteDollar20Bundle,
      noteDollar20Loose: cashDrawerTxn.noteDollar20Loose,
      noteDollar50Bundle: cashDrawerTxn.noteDollar50Bundle,
      noteDollar50Loose: cashDrawerTxn.noteDollar50Loose,
      noteDollar100Bundle: cashDrawerTxn.noteDollar100Bundle,
      noteDollar100Loose: cashDrawerTxn.noteDollar100Loose,
      createdBy: cashDrawerTxn.createdBy,
      creationDate: cashDrawerTxn.creationDate ? cashDrawerTxn.creationDate.format(DATE_TIME_FORMAT) : null,
      lastUpdatedBy: cashDrawerTxn.lastUpdatedBy,
      lastUpdateDate: cashDrawerTxn.lastUpdateDate ? cashDrawerTxn.lastUpdateDate.format(DATE_TIME_FORMAT) : null,
      cashDrawer: cashDrawerTxn.cashDrawer,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const cashDrawerTxn = this.createFromForm();
    if (cashDrawerTxn.id !== undefined) {
      this.subscribeToSaveResponse(this.cashDrawerTxnService.update(cashDrawerTxn));
    } else {
      this.subscribeToSaveResponse(this.cashDrawerTxnService.create(cashDrawerTxn));
    }
  }

  private createFromForm(): ICashDrawerTxn {
    return {
      ...new CashDrawerTxn(),
      id: this.editForm.get(['id'])!.value,
      txnDate: this.editForm.get(['txnDate'])!.value ? moment(this.editForm.get(['txnDate'])!.value, DATE_TIME_FORMAT) : undefined,
      txnCode: this.editForm.get(['txnCode'])!.value,
      txnStatus: this.editForm.get(['txnStatus'])!.value,
      txnAuthorisedUserCode: this.editForm.get(['txnAuthorisedUserCode'])!.value,
      txnAuthorisedDate: this.editForm.get(['txnAuthorisedDate'])!.value
        ? moment(this.editForm.get(['txnAuthorisedDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      txnAuthorisedReason: this.editForm.get(['txnAuthorisedReason'])!.value
        ? moment(this.editForm.get(['txnAuthorisedReason'])!.value, DATE_TIME_FORMAT)
        : undefined,
      totalCoinAmt: this.editForm.get(['totalCoinAmt'])!.value,
      totalNoteAmt: this.editForm.get(['totalNoteAmt'])!.value,
      totalCheckAmt: this.editForm.get(['totalCheckAmt'])!.value,
      totalPosAmt: this.editForm.get(['totalPosAmt'])!.value,
      coinCent1Roll: this.editForm.get(['coinCent1Roll'])!.value,
      coinCent1Lose: this.editForm.get(['coinCent1Lose'])!.value,
      coinCent5Roll: this.editForm.get(['coinCent5Roll'])!.value,
      coinCent5Loose: this.editForm.get(['coinCent5Loose'])!.value,
      coinCent10Roll: this.editForm.get(['coinCent10Roll'])!.value,
      coinCent10Loose: this.editForm.get(['coinCent10Loose'])!.value,
      coinCent25Roll: this.editForm.get(['coinCent25Roll'])!.value,
      coinCent25Loose: this.editForm.get(['coinCent25Loose'])!.value,
      coinCent50Roll: this.editForm.get(['coinCent50Roll'])!.value,
      coinCent50Loose: this.editForm.get(['coinCent50Loose'])!.value,
      coinDollar1Roll: this.editForm.get(['coinDollar1Roll'])!.value,
      coinDollar1Loose: this.editForm.get(['coinDollar1Loose'])!.value,
      noteDollar1Bundle: this.editForm.get(['noteDollar1Bundle'])!.value,
      noteDollar1Loose: this.editForm.get(['noteDollar1Loose'])!.value,
      noteDollar2Bundle: this.editForm.get(['noteDollar2Bundle'])!.value,
      noteDollar2Loose: this.editForm.get(['noteDollar2Loose'])!.value,
      noteDollar5Bundle: this.editForm.get(['noteDollar5Bundle'])!.value,
      noteDollar5Loose: this.editForm.get(['noteDollar5Loose'])!.value,
      noteDollar10Bundle: this.editForm.get(['noteDollar10Bundle'])!.value,
      noteDollar10Loose: this.editForm.get(['noteDollar10Loose'])!.value,
      noteDollar20Bundle: this.editForm.get(['noteDollar20Bundle'])!.value,
      noteDollar20Loose: this.editForm.get(['noteDollar20Loose'])!.value,
      noteDollar50Bundle: this.editForm.get(['noteDollar50Bundle'])!.value,
      noteDollar50Loose: this.editForm.get(['noteDollar50Loose'])!.value,
      noteDollar100Bundle: this.editForm.get(['noteDollar100Bundle'])!.value,
      noteDollar100Loose: this.editForm.get(['noteDollar100Loose'])!.value,
      createdBy: this.editForm.get(['createdBy'])!.value,
      creationDate: this.editForm.get(['creationDate'])!.value
        ? moment(this.editForm.get(['creationDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      lastUpdatedBy: this.editForm.get(['lastUpdatedBy'])!.value,
      lastUpdateDate: this.editForm.get(['lastUpdateDate'])!.value
        ? moment(this.editForm.get(['lastUpdateDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      cashDrawer: this.editForm.get(['cashDrawer'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICashDrawerTxn>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ICashDrawer): any {
    return item.id;
  }
}
