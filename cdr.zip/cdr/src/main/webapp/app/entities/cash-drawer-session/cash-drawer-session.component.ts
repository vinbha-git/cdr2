import { LocalStorageService } from 'ngx-webstorage';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { CashDrawerSessionService } from './cash-drawer-session.service';
import { CashDrawerSessionDeleteDialogComponent } from './cash-drawer-session-delete-dialog.component';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';

@Component({
  selector: 'jhi-cash-drawer-session',
  templateUrl: './cash-drawer-session.component.html',
})
export class CashDrawerSessionComponent implements OnInit, OnDestroy {
  cashDrawerSessions?: ICashDrawerSession[];
  eventSubscriber?: Subscription;
  currentSearch: string;
  cashDrawer?: ICashDrawer;

  constructor(
    protected lStorageService: LocalStorageService,
    protected cashDrawerSessionService: CashDrawerSessionService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal,
    protected activatedRoute: ActivatedRoute
  ) {
    this.currentSearch =
      this.activatedRoute.snapshot && this.activatedRoute.snapshot.queryParams['search']
        ? this.activatedRoute.snapshot.queryParams['search']
        : '';
  }

  loadAll(): void {
    if (this.currentSearch) {
      this.cashDrawerSessionService
        .search({
          query: this.currentSearch,
        })
        .subscribe((res: HttpResponse<ICashDrawerSession[]>) => (this.cashDrawerSessions = res.body || []));
      return;
    }

    this.cashDrawerSessionService
     .queryByCashDrawer(Number(this.cashDrawer?.id))
      .subscribe((res: HttpResponse<ICashDrawerSession[]>) => (this.cashDrawerSessions = res.body || []));
  }

  search(query: string): void {
    this.currentSearch = query;
    this.loadAll();
  }

  ngOnInit(): void {
   this.activatedRoute.data.subscribe(({ cashDrawer }) => { this.cashDrawer = cashDrawer; });
    const temp = this.lStorageService.retrieve("activeTab");
    if (temp !== null && temp !== undefined){ this.lStorageService.clear("activeTab"); }
    this.loadAll();
    this.registerChangeInCashDrawerSessions();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: ICashDrawerSession): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInCashDrawerSessions(): void {
    this.eventSubscriber = this.eventManager.subscribe('cashDrawerSessionListModification', () => this.loadAll());
  }

  delete(cashDrawerSession: ICashDrawerSession): void {
    const modalRef = this.modalService.open(CashDrawerSessionDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.cashDrawerSession = cashDrawerSession;
  }
}
