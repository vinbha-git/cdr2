import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawerSession, CashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { CashDrawerSessionService } from './cash-drawer-session.service';
import { CashDrawerSessionComponent } from './cash-drawer-session.component';
import { CashDrawerSessionDetailComponent } from './cash-drawer-session-detail.component';
import { CashDrawerSessionUpdateComponent } from './cash-drawer-session-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerSessionResolve implements Resolve<ICashDrawerSession> {
  constructor(private service: CashDrawerSessionService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawerSession> | Observable<never> {
    const id = route.params['ids'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawerSession: HttpResponse<CashDrawerSession>) => {
          if (cashDrawerSession.body) {
            return of(cashDrawerSession.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawerSession());
  }
}

export const cashDrawerSessionRoute: Routes = [
  {
    path: 'session',
    component: CashDrawerSessionComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerSession.home.title',
      title: 'Home / CashDrawer / Sessions',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':ids/viewsession',
    component: CashDrawerSessionDetailComponent,
    resolve: {
      cashDrawerSession: CashDrawerSessionResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerSession.home.title',
      title: 'Home / CashDrawer / Sessions / View',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'newsession',
    component: CashDrawerSessionUpdateComponent,
    resolve: {
      cashDrawerSession: CashDrawerSessionResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerSession.home.title',
      title: 'Home / CashDrawer / Sessions / New',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':ids/editsession',
    component: CashDrawerSessionUpdateComponent,
    resolve: {
      cashDrawerSession: CashDrawerSessionResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerSession.home.title',
      title: 'Home / CashDrawer / Sessions / Edit',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':ids/cash-drawer-payment-txn',
    loadChildren: () => import('../cash-drawer-payment-txn/cash-drawer-payment-txn.module').then(m => m.CdrCashDrawerPaymentTxnModule),
  },
];
