import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';
import { CashDrawerPaymentTxnService } from './cash-drawer-payment-txn.service';
import { CashDrawerPaymentTxnDeleteDialogComponent } from './cash-drawer-payment-txn-delete-dialog.component';

import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';

@Component({
  selector: 'jhi-cash-drawer-payment-txn',
  templateUrl: './cash-drawer-payment-txn.component.html',
})
export class CashDrawerPaymentTxnComponent implements OnInit, OnDestroy {
  cashDrawerPaymentTxns?: ICashDrawerPaymentTxn[];
  eventSubscriber?: Subscription;
  currentSearch: string;
  cashDrawerSession?: ICashDrawerSession;

  constructor(
    protected cashDrawerPaymentTxnService: CashDrawerPaymentTxnService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal,
    protected activatedRoute: ActivatedRoute
  ) {
    this.currentSearch =
      this.activatedRoute.snapshot && this.activatedRoute.snapshot.queryParams['search']
        ? this.activatedRoute.snapshot.queryParams['search']
        : '';
  }

  loadAll(): void {
    if (this.currentSearch) {
      this.cashDrawerPaymentTxnService
        .search({
          query: this.currentSearch,
        })
        .subscribe((res: HttpResponse<ICashDrawerPaymentTxn[]>) => (this.cashDrawerPaymentTxns = res.body || []));
      return;
    }

    this.cashDrawerPaymentTxnService
     .queryByCashDrawerSession(Number(this.cashDrawerSession?.id))
      .subscribe((res: HttpResponse<ICashDrawerPaymentTxn[]>) => (this.cashDrawerPaymentTxns = res.body || []));
  }

  search(query: string): void {
    this.currentSearch = query;
    this.loadAll();
  }

  ngOnInit(): void {
   this.activatedRoute.data.subscribe(({ cashDrawerSession }) => { this.cashDrawerSession = cashDrawerSession; });
    this.loadAll();
    this.registerChangeInCashDrawerPaymentTxns();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: ICashDrawerPaymentTxn): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInCashDrawerPaymentTxns(): void {
    this.eventSubscriber = this.eventManager.subscribe('cashDrawerPaymentTxnListModification', () => this.loadAll());
  }

  delete(cashDrawerPaymentTxn: ICashDrawerPaymentTxn): void {
    const modalRef = this.modalService.open(CashDrawerPaymentTxnDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.cashDrawerPaymentTxn = cashDrawerPaymentTxn;
  }
}
