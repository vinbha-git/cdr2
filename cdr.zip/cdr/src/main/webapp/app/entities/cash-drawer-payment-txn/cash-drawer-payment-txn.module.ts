import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CdrSharedModule } from 'app/shared/shared.module';
import { CashDrawerPaymentTxnComponent } from './cash-drawer-payment-txn.component';
import { CashDrawerPaymentTxnDetailComponent } from './cash-drawer-payment-txn-detail.component';
import { CashDrawerPaymentTxnUpdateComponent } from './cash-drawer-payment-txn-update.component';
import { CashDrawerPaymentTxnDeleteDialogComponent } from './cash-drawer-payment-txn-delete-dialog.component';
import { cashDrawerPaymentTxnRoute } from './cash-drawer-payment-txn.route';

@NgModule({
  imports: [CdrSharedModule, RouterModule.forChild(cashDrawerPaymentTxnRoute)],
  declarations: [
    CashDrawerPaymentTxnComponent,
    CashDrawerPaymentTxnDetailComponent,
    CashDrawerPaymentTxnUpdateComponent,
    CashDrawerPaymentTxnDeleteDialogComponent,
  ],
  entryComponents: [CashDrawerPaymentTxnDeleteDialogComponent],
  exports: [CashDrawerPaymentTxnComponent],
})
export class CdrCashDrawerPaymentTxnModule {}
