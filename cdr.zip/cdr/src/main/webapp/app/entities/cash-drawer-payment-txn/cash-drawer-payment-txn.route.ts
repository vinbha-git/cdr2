import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawerPaymentTxn, CashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';
import { CashDrawerPaymentTxnService } from './cash-drawer-payment-txn.service';
import { CashDrawerPaymentTxnComponent } from './cash-drawer-payment-txn.component';
import { CashDrawerPaymentTxnDetailComponent } from './cash-drawer-payment-txn-detail.component';
import { CashDrawerPaymentTxnUpdateComponent } from './cash-drawer-payment-txn-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerPaymentTxnResolve implements Resolve<ICashDrawerPaymentTxn> {
  constructor(private service: CashDrawerPaymentTxnService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawerPaymentTxn> | Observable<never> {
    const id = route.params['idc'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawerPaymentTxn: HttpResponse<CashDrawerPaymentTxn>) => {
          if (cashDrawerPaymentTxn.body) {
            return of(cashDrawerPaymentTxn.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawerPaymentTxn());
  }
}

export const cashDrawerPaymentTxnRoute: Routes = [
  {
    path: 'cashdrawerpaymenttxn',
    component: CashDrawerPaymentTxnComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerPaymentTxn.home.title',
      title: 'Home / CashDrawerSession / CashDrawerPaymentTxns',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idc/viewcashdrawerpaymenttxn',
    component: CashDrawerPaymentTxnDetailComponent,
    resolve: {
      cashDrawerPaymentTxn: CashDrawerPaymentTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerPaymentTxn.home.title',
      title: 'Home / CashDrawerSession / CashDrawerPaymentTxns / View',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'newcashdrawerpaymenttxn',
    component: CashDrawerPaymentTxnUpdateComponent,
    resolve: {
      cashDrawerPaymentTxn: CashDrawerPaymentTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerPaymentTxn.home.title',
      title: 'Home / CashDrawerSession / CashDrawerPaymentTxns / New',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':idc/editcashdrawerpaymenttxn',
    component: CashDrawerPaymentTxnUpdateComponent,
    resolve: {
      cashDrawerPaymentTxn: CashDrawerPaymentTxnResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerPaymentTxn.home.title',
      title: 'Home / CashDrawerSession / CashDrawerPaymentTxns / Edit',
    },
    canActivate: [UserRouteAccessService],
  },
];
