import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { AccountService } from 'app/core/auth/account.service';
import { Account } from 'app/core/user/account.model';

import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { ICashDrawer, CashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from './cash-drawer.service';

@Component({
  selector: 'jhi-cash-drawer-update',
  templateUrl: './cash-drawer-update.component.html',
})
export class CashDrawerUpdateComponent implements OnInit {
  isSaving = false;
  account: Account | null = null;
  authSubscription?: Subscription;

  editForm = this.fb.group({
    id: [],
    code: [null, [Validators.required]],
    company: [null, [Validators.required]],
    branch: [null, [Validators.required]],
    status: [],
    cashierUsrCode: [null, [Validators.required]],
    cashBalance: [null, [Validators.required]],
    checkBalance: [null, [Validators.required]],
    posBalance: [null, [Validators.required]],
    cashLimit: [null, [Validators.required]],
    changeLimit: [null, [Validators.required]],
    mainIndicator: [null, [Validators.required]],
    createdBy: [],
    creationDate: [],
    lastUpdatedBy: [],
    lastUpdateDate: [],
  });

  constructor(protected cashDrawerService: CashDrawerService, protected activatedRoute: ActivatedRoute, private fb: FormBuilder,protected accountService: AccountService) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawer }) => {
     this.authSubscription = this.accountService.getAuthenticationState().subscribe(account => (this.account = account));
      if (!cashDrawer.id) {
        const today = moment().startOf('day');
        cashDrawer.creationDate = today;
        cashDrawer.lastUpdateDate = today;
        cashDrawer.createdBy = this.account?.login;
        cashDrawer.lastUpdatedBy = this.account?.login;
      } else {
        const today = moment().startOf('day');
        cashDrawer.lastUpdateDate = today;
        cashDrawer.lastUpdatedBy = this.account?.login;
      }

      this.updateForm(cashDrawer);
    });
  }

  updateForm(cashDrawer: ICashDrawer): void {
    this.editForm.patchValue({
      id: cashDrawer.id,
      code: cashDrawer.code,
      company: cashDrawer.company,
      branch: cashDrawer.branch,
      status: cashDrawer.status,
      cashierUsrCode: cashDrawer.cashierUsrCode,
      cashBalance: cashDrawer.cashBalance,
      checkBalance: cashDrawer.checkBalance,
      posBalance: cashDrawer.posBalance,
      cashLimit: cashDrawer.cashLimit,
      changeLimit: cashDrawer.changeLimit,
      mainIndicator: cashDrawer.mainIndicator,
      createdBy: cashDrawer.createdBy,
      creationDate: cashDrawer.creationDate ? cashDrawer.creationDate.format(DATE_TIME_FORMAT) : null,
      lastUpdatedBy: cashDrawer.lastUpdatedBy,
      lastUpdateDate: cashDrawer.lastUpdateDate ? cashDrawer.lastUpdateDate.format(DATE_TIME_FORMAT) : null,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const cashDrawer = this.createFromForm();
    if (cashDrawer.id !== undefined) {
      this.subscribeToSaveResponse(this.cashDrawerService.update(cashDrawer));
    } else {
      this.subscribeToSaveResponse(this.cashDrawerService.create(cashDrawer));
    }
  }

  private createFromForm(): ICashDrawer {
    return {
      ...new CashDrawer(),
      id: this.editForm.get(['id'])!.value,
      code: this.editForm.get(['code'])!.value,
      company: this.editForm.get(['company'])!.value,
      branch: this.editForm.get(['branch'])!.value,
      status: this.editForm.get(['status'])!.value,
      cashierUsrCode: this.editForm.get(['cashierUsrCode'])!.value,
      cashBalance: this.editForm.get(['cashBalance'])!.value,
      checkBalance: this.editForm.get(['checkBalance'])!.value,
      posBalance: this.editForm.get(['posBalance'])!.value,
      cashLimit: this.editForm.get(['cashLimit'])!.value,
      changeLimit: this.editForm.get(['changeLimit'])!.value,
      mainIndicator: this.editForm.get(['mainIndicator'])!.value,
      createdBy: this.editForm.get(['createdBy'])!.value,
      creationDate: this.editForm.get(['creationDate'])!.value
        ? moment(this.editForm.get(['creationDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      lastUpdatedBy: this.editForm.get(['lastUpdatedBy'])!.value,
      lastUpdateDate: this.editForm.get(['lastUpdateDate'])!.value
        ? moment(this.editForm.get(['lastUpdateDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICashDrawer>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }
}
