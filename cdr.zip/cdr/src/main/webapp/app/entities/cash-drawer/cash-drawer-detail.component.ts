import { LocalStorageService } from 'ngx-webstorage';
import { NgbTabChangeEvent } from "@ng-bootstrap/ng-bootstrap"
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';

@Component({
  selector: 'jhi-cash-drawer-detail',
  templateUrl: './cash-drawer-detail.component.html',
})
export class CashDrawerDetailComponent implements OnInit {
  cashDrawer: ICashDrawer | null = null;

    public activeTab: any;
    constructor(protected activatedRoute: ActivatedRoute,protected lStorageService: LocalStorageService) {}

  ngOnInit(): void {
    const temp = this.lStorageService.retrieve("activeTab");
    if (temp !== null && temp !== undefined){ this.activeTab = temp }
    this.activatedRoute.data.subscribe(({ cashDrawer }) => (this.cashDrawer = cashDrawer));
  }

   beforeChange($event: NgbTabChangeEvent): void {
   this.activeTab = $event.nextId;
   // const state=window.history.state;
   // state['tabId']=this.activeTab;
   this.lStorageService.store("activeTab", this.activeTab);
   }

  previousState(): void {
    window.history.back();
  }
}
