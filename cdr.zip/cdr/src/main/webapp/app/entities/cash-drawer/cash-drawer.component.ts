import { LocalStorageService } from 'ngx-webstorage';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from './cash-drawer.service';
import { CashDrawerDeleteDialogComponent } from './cash-drawer-delete-dialog.component';

@Component({
  selector: 'jhi-cash-drawer',
  templateUrl: './cash-drawer.component.html',
})
export class CashDrawerComponent implements OnInit, OnDestroy {
  cashDrawers?: ICashDrawer[];
  eventSubscriber?: Subscription;
  currentSearch: string;

  constructor(
    protected lStorageService: LocalStorageService,
    protected cashDrawerService: CashDrawerService,
    protected eventManager: JhiEventManager,
    protected modalService: NgbModal,
    protected activatedRoute: ActivatedRoute
  ) {
    this.currentSearch =
      this.activatedRoute.snapshot && this.activatedRoute.snapshot.queryParams['search']
        ? this.activatedRoute.snapshot.queryParams['search']
        : '';
  }

  loadAll(): void {
    if (this.currentSearch) {
      this.cashDrawerService
        .search({
          query: this.currentSearch,
        })
        .subscribe((res: HttpResponse<ICashDrawer[]>) => (this.cashDrawers = res.body || []));
      return;
    }

    this.cashDrawerService.query().subscribe((res: HttpResponse<ICashDrawer[]>) => (this.cashDrawers = res.body || []));
  }

  search(query: string): void {
    this.currentSearch = query;
    this.loadAll();
  }

  ngOnInit(): void {
    const temp = this.lStorageService.retrieve("activeTab");
    if (temp !== null && temp !== undefined){ this.lStorageService.clear("activeTab"); }
    this.loadAll();
    this.registerChangeInCashDrawers();
  }

  ngOnDestroy(): void {
    if (this.eventSubscriber) {
      this.eventManager.destroy(this.eventSubscriber);
    }
  }

  trackId(index: number, item: ICashDrawer): number {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
    return item.id!;
  }

  registerChangeInCashDrawers(): void {
    this.eventSubscriber = this.eventManager.subscribe('cashDrawerListModification', () => this.loadAll());
  }

  delete(cashDrawer: ICashDrawer): void {
    const modalRef = this.modalService.open(CashDrawerDeleteDialogComponent, { size: 'lg', backdrop: 'static' });
    modalRef.componentInstance.cashDrawer = cashDrawer;
  }
}
