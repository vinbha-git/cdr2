import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CdrSharedModule } from 'app/shared/shared.module';
import { CashDrawerComponent } from './cash-drawer.component';
import { CashDrawerDetailComponent } from './cash-drawer-detail.component';
import { CashDrawerUpdateComponent } from './cash-drawer-update.component';
import { CashDrawerDeleteDialogComponent } from './cash-drawer-delete-dialog.component';
import { cashDrawerRoute } from './cash-drawer.route';

import { CdrCashDrawerTxnModule } from '../cash-drawer-txn/cash-drawer-txn.module';
import { CdrCashDrawerSessionModule } from '../cash-drawer-session/cash-drawer-session.module';
@NgModule({
  imports: [      CdrCashDrawerTxnModule,
      CdrCashDrawerSessionModule,
CdrSharedModule, RouterModule.forChild(cashDrawerRoute)],
  declarations: [CashDrawerComponent, CashDrawerDetailComponent, CashDrawerUpdateComponent, CashDrawerDeleteDialogComponent],
  entryComponents: [CashDrawerDeleteDialogComponent],
})
export class CdrCashDrawerModule {}
