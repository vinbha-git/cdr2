import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { CashDrawerTxnService } from './cash-drawer-txn.service';

@Component({
  templateUrl: './cash-drawer-txn-delete-dialog.component.html',
})
export class CashDrawerTxnDeleteDialogComponent {
  cashDrawerTxn?: ICashDrawerTxn;

  constructor(
    protected cashDrawerTxnService: CashDrawerTxnService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.cashDrawerTxnService.delete(id).subscribe(() => {
      this.eventManager.broadcast('cashDrawerTxnListModification');
      this.activeModal.close();
    });
  }
}
