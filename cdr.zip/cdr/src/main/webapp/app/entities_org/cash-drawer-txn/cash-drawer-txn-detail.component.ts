import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';

@Component({
  selector: 'jhi-cash-drawer-txn-detail',
  templateUrl: './cash-drawer-txn-detail.component.html',
})
export class CashDrawerTxnDetailComponent implements OnInit {
  cashDrawerTxn: ICashDrawerTxn | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerTxn }) => (this.cashDrawerTxn = cashDrawerTxn));
  }

  previousState(): void {
    window.history.back();
  }
}
