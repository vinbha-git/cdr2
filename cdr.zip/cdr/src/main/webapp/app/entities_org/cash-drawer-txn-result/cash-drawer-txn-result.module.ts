import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CdrSharedModule } from 'app/shared/shared.module';
import { CashDrawerTxnResultComponent } from './cash-drawer-txn-result.component';
import { CashDrawerTxnResultDetailComponent } from './cash-drawer-txn-result-detail.component';
import { CashDrawerTxnResultUpdateComponent } from './cash-drawer-txn-result-update.component';
import { CashDrawerTxnResultDeleteDialogComponent } from './cash-drawer-txn-result-delete-dialog.component';
import { cashDrawerTxnResultRoute } from './cash-drawer-txn-result.route';

@NgModule({
  imports: [CdrSharedModule, RouterModule.forChild(cashDrawerTxnResultRoute)],
  declarations: [
    CashDrawerTxnResultComponent,
    CashDrawerTxnResultDetailComponent,
    CashDrawerTxnResultUpdateComponent,
    CashDrawerTxnResultDeleteDialogComponent,
  ],
  entryComponents: [CashDrawerTxnResultDeleteDialogComponent],
})
export class CdrCashDrawerTxnResultModule {}
