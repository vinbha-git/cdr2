import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { ICashDrawerTxnResult, CashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';
import { CashDrawerTxnResultService } from './cash-drawer-txn-result.service';
import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { CashDrawerTxnService } from 'app/entities/cash-drawer-txn/cash-drawer-txn.service';

@Component({
  selector: 'jhi-cash-drawer-txn-result-update',
  templateUrl: './cash-drawer-txn-result-update.component.html',
})
export class CashDrawerTxnResultUpdateComponent implements OnInit {
  isSaving = false;
  cashdrawertxns: ICashDrawerTxn[] = [];

  editForm = this.fb.group({
    id: [],
    systemCashBalance: [null, [Validators.required]],
    systemCheckBalance: [null, [Validators.required]],
    systemPosBalance: [null, [Validators.required]],
    enteredCashBalance: [null, [Validators.required]],
    enteredCheckBalance: [null, [Validators.required]],
    enteredPosBalance: [null, [Validators.required]],
    createdBy: [],
    creationDate: [],
    lastUpdatedBy: [],
    lastUpdateDate: [],
    cashDrawerTxn: [],
  });

  constructor(
    protected cashDrawerTxnResultService: CashDrawerTxnResultService,
    protected cashDrawerTxnService: CashDrawerTxnService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerTxnResult }) => {
      if (!cashDrawerTxnResult.id) {
        const today = moment().startOf('day');
        cashDrawerTxnResult.creationDate = today;
        cashDrawerTxnResult.lastUpdateDate = today;
      }

      this.updateForm(cashDrawerTxnResult);

      this.cashDrawerTxnService.query().subscribe((res: HttpResponse<ICashDrawerTxn[]>) => (this.cashdrawertxns = res.body || []));
    });
  }

  updateForm(cashDrawerTxnResult: ICashDrawerTxnResult): void {
    this.editForm.patchValue({
      id: cashDrawerTxnResult.id,
      systemCashBalance: cashDrawerTxnResult.systemCashBalance,
      systemCheckBalance: cashDrawerTxnResult.systemCheckBalance,
      systemPosBalance: cashDrawerTxnResult.systemPosBalance,
      enteredCashBalance: cashDrawerTxnResult.enteredCashBalance,
      enteredCheckBalance: cashDrawerTxnResult.enteredCheckBalance,
      enteredPosBalance: cashDrawerTxnResult.enteredPosBalance,
      createdBy: cashDrawerTxnResult.createdBy,
      creationDate: cashDrawerTxnResult.creationDate ? cashDrawerTxnResult.creationDate.format(DATE_TIME_FORMAT) : null,
      lastUpdatedBy: cashDrawerTxnResult.lastUpdatedBy,
      lastUpdateDate: cashDrawerTxnResult.lastUpdateDate ? cashDrawerTxnResult.lastUpdateDate.format(DATE_TIME_FORMAT) : null,
      cashDrawerTxn: cashDrawerTxnResult.cashDrawerTxn,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const cashDrawerTxnResult = this.createFromForm();
    if (cashDrawerTxnResult.id !== undefined) {
      this.subscribeToSaveResponse(this.cashDrawerTxnResultService.update(cashDrawerTxnResult));
    } else {
      this.subscribeToSaveResponse(this.cashDrawerTxnResultService.create(cashDrawerTxnResult));
    }
  }

  private createFromForm(): ICashDrawerTxnResult {
    return {
      ...new CashDrawerTxnResult(),
      id: this.editForm.get(['id'])!.value,
      systemCashBalance: this.editForm.get(['systemCashBalance'])!.value,
      systemCheckBalance: this.editForm.get(['systemCheckBalance'])!.value,
      systemPosBalance: this.editForm.get(['systemPosBalance'])!.value,
      enteredCashBalance: this.editForm.get(['enteredCashBalance'])!.value,
      enteredCheckBalance: this.editForm.get(['enteredCheckBalance'])!.value,
      enteredPosBalance: this.editForm.get(['enteredPosBalance'])!.value,
      createdBy: this.editForm.get(['createdBy'])!.value,
      creationDate: this.editForm.get(['creationDate'])!.value
        ? moment(this.editForm.get(['creationDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      lastUpdatedBy: this.editForm.get(['lastUpdatedBy'])!.value,
      lastUpdateDate: this.editForm.get(['lastUpdateDate'])!.value
        ? moment(this.editForm.get(['lastUpdateDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      cashDrawerTxn: this.editForm.get(['cashDrawerTxn'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICashDrawerTxnResult>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ICashDrawerTxn): any {
    return item.id;
  }
}
