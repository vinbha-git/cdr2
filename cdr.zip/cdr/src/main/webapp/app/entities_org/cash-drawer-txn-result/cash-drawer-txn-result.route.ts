import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawerTxnResult, CashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';
import { CashDrawerTxnResultService } from './cash-drawer-txn-result.service';
import { CashDrawerTxnResultComponent } from './cash-drawer-txn-result.component';
import { CashDrawerTxnResultDetailComponent } from './cash-drawer-txn-result-detail.component';
import { CashDrawerTxnResultUpdateComponent } from './cash-drawer-txn-result-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerTxnResultResolve implements Resolve<ICashDrawerTxnResult> {
  constructor(private service: CashDrawerTxnResultService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawerTxnResult> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawerTxnResult: HttpResponse<CashDrawerTxnResult>) => {
          if (cashDrawerTxnResult.body) {
            return of(cashDrawerTxnResult.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawerTxnResult());
  }
}

export const cashDrawerTxnResultRoute: Routes = [
  {
    path: '',
    component: CashDrawerTxnResultComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: CashDrawerTxnResultDetailComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: CashDrawerTxnResultUpdateComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: CashDrawerTxnResultUpdateComponent,
    resolve: {
      cashDrawerTxnResult: CashDrawerTxnResultResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawerTxnResult.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
];
