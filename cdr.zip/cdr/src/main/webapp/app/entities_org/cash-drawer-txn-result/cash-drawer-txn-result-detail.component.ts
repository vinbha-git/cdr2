import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';

@Component({
  selector: 'jhi-cash-drawer-txn-result-detail',
  templateUrl: './cash-drawer-txn-result-detail.component.html',
})
export class CashDrawerTxnResultDetailComponent implements OnInit {
  cashDrawerTxnResult: ICashDrawerTxnResult | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerTxnResult }) => (this.cashDrawerTxnResult = cashDrawerTxnResult));
  }

  previousState(): void {
    window.history.back();
  }
}
