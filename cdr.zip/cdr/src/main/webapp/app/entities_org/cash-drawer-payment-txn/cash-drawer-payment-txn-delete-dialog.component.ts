import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ICashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';
import { CashDrawerPaymentTxnService } from './cash-drawer-payment-txn.service';

@Component({
  templateUrl: './cash-drawer-payment-txn-delete-dialog.component.html',
})
export class CashDrawerPaymentTxnDeleteDialogComponent {
  cashDrawerPaymentTxn?: ICashDrawerPaymentTxn;

  constructor(
    protected cashDrawerPaymentTxnService: CashDrawerPaymentTxnService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.cashDrawerPaymentTxnService.delete(id).subscribe(() => {
      this.eventManager.broadcast('cashDrawerPaymentTxnListModification');
      this.activeModal.close();
    });
  }
}
