import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';

@Component({
  selector: 'jhi-cash-drawer-payment-txn-detail',
  templateUrl: './cash-drawer-payment-txn-detail.component.html',
})
export class CashDrawerPaymentTxnDetailComponent implements OnInit {
  cashDrawerPaymentTxn: ICashDrawerPaymentTxn | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerPaymentTxn }) => (this.cashDrawerPaymentTxn = cashDrawerPaymentTxn));
  }

  previousState(): void {
    window.history.back();
  }
}
