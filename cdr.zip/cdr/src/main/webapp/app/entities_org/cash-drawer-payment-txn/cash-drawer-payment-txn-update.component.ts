import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { ICashDrawerPaymentTxn, CashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';
import { CashDrawerPaymentTxnService } from './cash-drawer-payment-txn.service';
import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { CashDrawerSessionService } from 'app/entities/cash-drawer-session/cash-drawer-session.service';

@Component({
  selector: 'jhi-cash-drawer-payment-txn-update',
  templateUrl: './cash-drawer-payment-txn-update.component.html',
})
export class CashDrawerPaymentTxnUpdateComponent implements OnInit {
  isSaving = false;
  cashdrawersessions: ICashDrawerSession[] = [];

  editForm = this.fb.group({
    id: [],
    txnDate: [null, [Validators.required]],
    customerFirstName: [null, [Validators.required]],
    customerLastName: [null, [Validators.required]],
    customerNbr: [],
    customerPhone: [null, [Validators.required]],
    cstomerAccountNumber: [null, [Validators.required]],
    dueAmt: [null, [Validators.required]],
    cashAmt: [null, [Validators.required]],
    checkAmt: [null, [Validators.required]],
    posAmt: [null, [Validators.required]],
    changeAmt: [null, [Validators.required]],
    checkNumber: [],
    posReference: [],
    createdBy: [],
    creationDate: [],
    lastUpdatedBy: [],
    lastUpdateDate: [],
    cashDrawerSession: [],
  });

  constructor(
    protected cashDrawerPaymentTxnService: CashDrawerPaymentTxnService,
    protected cashDrawerSessionService: CashDrawerSessionService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerPaymentTxn }) => {
      if (!cashDrawerPaymentTxn.id) {
        const today = moment().startOf('day');
        cashDrawerPaymentTxn.txnDate = today;
        cashDrawerPaymentTxn.creationDate = today;
        cashDrawerPaymentTxn.lastUpdateDate = today;
      }

      this.updateForm(cashDrawerPaymentTxn);

      this.cashDrawerSessionService
        .query()
        .subscribe((res: HttpResponse<ICashDrawerSession[]>) => (this.cashdrawersessions = res.body || []));
    });
  }

  updateForm(cashDrawerPaymentTxn: ICashDrawerPaymentTxn): void {
    this.editForm.patchValue({
      id: cashDrawerPaymentTxn.id,
      txnDate: cashDrawerPaymentTxn.txnDate ? cashDrawerPaymentTxn.txnDate.format(DATE_TIME_FORMAT) : null,
      customerFirstName: cashDrawerPaymentTxn.customerFirstName,
      customerLastName: cashDrawerPaymentTxn.customerLastName,
      customerNbr: cashDrawerPaymentTxn.customerNbr,
      customerPhone: cashDrawerPaymentTxn.customerPhone,
      cstomerAccountNumber: cashDrawerPaymentTxn.cstomerAccountNumber,
      dueAmt: cashDrawerPaymentTxn.dueAmt,
      cashAmt: cashDrawerPaymentTxn.cashAmt,
      checkAmt: cashDrawerPaymentTxn.checkAmt,
      posAmt: cashDrawerPaymentTxn.posAmt,
      changeAmt: cashDrawerPaymentTxn.changeAmt,
      checkNumber: cashDrawerPaymentTxn.checkNumber,
      posReference: cashDrawerPaymentTxn.posReference,
      createdBy: cashDrawerPaymentTxn.createdBy,
      creationDate: cashDrawerPaymentTxn.creationDate ? cashDrawerPaymentTxn.creationDate.format(DATE_TIME_FORMAT) : null,
      lastUpdatedBy: cashDrawerPaymentTxn.lastUpdatedBy,
      lastUpdateDate: cashDrawerPaymentTxn.lastUpdateDate ? cashDrawerPaymentTxn.lastUpdateDate.format(DATE_TIME_FORMAT) : null,
      cashDrawerSession: cashDrawerPaymentTxn.cashDrawerSession,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const cashDrawerPaymentTxn = this.createFromForm();
    if (cashDrawerPaymentTxn.id !== undefined) {
      this.subscribeToSaveResponse(this.cashDrawerPaymentTxnService.update(cashDrawerPaymentTxn));
    } else {
      this.subscribeToSaveResponse(this.cashDrawerPaymentTxnService.create(cashDrawerPaymentTxn));
    }
  }

  private createFromForm(): ICashDrawerPaymentTxn {
    return {
      ...new CashDrawerPaymentTxn(),
      id: this.editForm.get(['id'])!.value,
      txnDate: this.editForm.get(['txnDate'])!.value ? moment(this.editForm.get(['txnDate'])!.value, DATE_TIME_FORMAT) : undefined,
      customerFirstName: this.editForm.get(['customerFirstName'])!.value,
      customerLastName: this.editForm.get(['customerLastName'])!.value,
      customerNbr: this.editForm.get(['customerNbr'])!.value,
      customerPhone: this.editForm.get(['customerPhone'])!.value,
      cstomerAccountNumber: this.editForm.get(['cstomerAccountNumber'])!.value,
      dueAmt: this.editForm.get(['dueAmt'])!.value,
      cashAmt: this.editForm.get(['cashAmt'])!.value,
      checkAmt: this.editForm.get(['checkAmt'])!.value,
      posAmt: this.editForm.get(['posAmt'])!.value,
      changeAmt: this.editForm.get(['changeAmt'])!.value,
      checkNumber: this.editForm.get(['checkNumber'])!.value,
      posReference: this.editForm.get(['posReference'])!.value,
      createdBy: this.editForm.get(['createdBy'])!.value,
      creationDate: this.editForm.get(['creationDate'])!.value
        ? moment(this.editForm.get(['creationDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      lastUpdatedBy: this.editForm.get(['lastUpdatedBy'])!.value,
      lastUpdateDate: this.editForm.get(['lastUpdateDate'])!.value
        ? moment(this.editForm.get(['lastUpdateDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      cashDrawerSession: this.editForm.get(['cashDrawerSession'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICashDrawerPaymentTxn>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ICashDrawerSession): any {
    return item.id;
  }
}
