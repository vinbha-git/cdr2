import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as moment from 'moment';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption, Search } from 'app/shared/util/request-util';
import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';

type EntityResponseType = HttpResponse<ICashDrawerSession>;
type EntityArrayResponseType = HttpResponse<ICashDrawerSession[]>;

@Injectable({ providedIn: 'root' })
export class CashDrawerSessionService {
  public resourceUrl = SERVER_API_URL + 'api/cash-drawer-sessions';
  public resourceSearchUrl = SERVER_API_URL + 'api/_search/cash-drawer-sessions';

  constructor(protected http: HttpClient) {}

  create(cashDrawerSession: ICashDrawerSession): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(cashDrawerSession);
    return this.http
      .post<ICashDrawerSession>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(cashDrawerSession: ICashDrawerSession): Observable<EntityResponseType> {
    const copy = this.convertDateFromClient(cashDrawerSession);
    return this.http
      .put<ICashDrawerSession>(this.resourceUrl, copy, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<ICashDrawerSession>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<ICashDrawerSession[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  search(req: Search): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<ICashDrawerSession[]>(this.resourceSearchUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  protected convertDateFromClient(cashDrawerSession: ICashDrawerSession): ICashDrawerSession {
    const copy: ICashDrawerSession = Object.assign({}, cashDrawerSession, {
      sessionStartTime:
        cashDrawerSession.sessionStartTime && cashDrawerSession.sessionStartTime.isValid()
          ? cashDrawerSession.sessionStartTime.toJSON()
          : undefined,
      sessionEndTime:
        cashDrawerSession.sessionEndTime && cashDrawerSession.sessionEndTime.isValid()
          ? cashDrawerSession.sessionEndTime.toJSON()
          : undefined,
      creationDate:
        cashDrawerSession.creationDate && cashDrawerSession.creationDate.isValid() ? cashDrawerSession.creationDate.toJSON() : undefined,
      lastUpdateDate:
        cashDrawerSession.lastUpdateDate && cashDrawerSession.lastUpdateDate.isValid()
          ? cashDrawerSession.lastUpdateDate.toJSON()
          : undefined,
    });
    return copy;
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.sessionStartTime = res.body.sessionStartTime ? moment(res.body.sessionStartTime) : undefined;
      res.body.sessionEndTime = res.body.sessionEndTime ? moment(res.body.sessionEndTime) : undefined;
      res.body.creationDate = res.body.creationDate ? moment(res.body.creationDate) : undefined;
      res.body.lastUpdateDate = res.body.lastUpdateDate ? moment(res.body.lastUpdateDate) : undefined;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((cashDrawerSession: ICashDrawerSession) => {
        cashDrawerSession.sessionStartTime = cashDrawerSession.sessionStartTime ? moment(cashDrawerSession.sessionStartTime) : undefined;
        cashDrawerSession.sessionEndTime = cashDrawerSession.sessionEndTime ? moment(cashDrawerSession.sessionEndTime) : undefined;
        cashDrawerSession.creationDate = cashDrawerSession.creationDate ? moment(cashDrawerSession.creationDate) : undefined;
        cashDrawerSession.lastUpdateDate = cashDrawerSession.lastUpdateDate ? moment(cashDrawerSession.lastUpdateDate) : undefined;
      });
    }
    return res;
  }
}
