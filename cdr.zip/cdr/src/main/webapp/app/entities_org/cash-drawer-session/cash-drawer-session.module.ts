import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CdrSharedModule } from 'app/shared/shared.module';
import { CashDrawerSessionComponent } from './cash-drawer-session.component';
import { CashDrawerSessionDetailComponent } from './cash-drawer-session-detail.component';
import { CashDrawerSessionUpdateComponent } from './cash-drawer-session-update.component';
import { CashDrawerSessionDeleteDialogComponent } from './cash-drawer-session-delete-dialog.component';
import { cashDrawerSessionRoute } from './cash-drawer-session.route';

@NgModule({
  imports: [CdrSharedModule, RouterModule.forChild(cashDrawerSessionRoute)],
  declarations: [
    CashDrawerSessionComponent,
    CashDrawerSessionDetailComponent,
    CashDrawerSessionUpdateComponent,
    CashDrawerSessionDeleteDialogComponent,
  ],
  entryComponents: [CashDrawerSessionDeleteDialogComponent],
})
export class CdrCashDrawerSessionModule {}
