import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { ICashDrawerSession, CashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { CashDrawerSessionService } from './cash-drawer-session.service';
import { ICashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from 'app/entities/cash-drawer/cash-drawer.service';

@Component({
  selector: 'jhi-cash-drawer-session-update',
  templateUrl: './cash-drawer-session-update.component.html',
})
export class CashDrawerSessionUpdateComponent implements OnInit {
  isSaving = false;
  cashdrawers: ICashDrawer[] = [];

  editForm = this.fb.group({
    id: [],
    currentIndicator: [null, [Validators.required]],
    cashierUsrCode: [null, [Validators.required]],
    cashOpen: [null, [Validators.required]],
    cashCurrent: [null, [Validators.required]],
    cashClose: [null, [Validators.required]],
    checkOpen: [null, [Validators.required]],
    checkCurrent: [null, [Validators.required]],
    checkClose: [null, [Validators.required]],
    posOpen: [null, [Validators.required]],
    posCurrent: [null, [Validators.required]],
    posClose: [null, [Validators.required]],
    sessionStartTime: [null, [Validators.required]],
    sessionEndTime: [null, [Validators.required]],
    createdBy: [],
    creationDate: [],
    lastUpdatedBy: [],
    lastUpdateDate: [],
    cashDrawer: [],
  });

  constructor(
    protected cashDrawerSessionService: CashDrawerSessionService,
    protected cashDrawerService: CashDrawerService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerSession }) => {
      if (!cashDrawerSession.id) {
        const today = moment().startOf('day');
        cashDrawerSession.sessionStartTime = today;
        cashDrawerSession.sessionEndTime = today;
        cashDrawerSession.creationDate = today;
        cashDrawerSession.lastUpdateDate = today;
      }

      this.updateForm(cashDrawerSession);

      this.cashDrawerService.query().subscribe((res: HttpResponse<ICashDrawer[]>) => (this.cashdrawers = res.body || []));
    });
  }

  updateForm(cashDrawerSession: ICashDrawerSession): void {
    this.editForm.patchValue({
      id: cashDrawerSession.id,
      currentIndicator: cashDrawerSession.currentIndicator,
      cashierUsrCode: cashDrawerSession.cashierUsrCode,
      cashOpen: cashDrawerSession.cashOpen,
      cashCurrent: cashDrawerSession.cashCurrent,
      cashClose: cashDrawerSession.cashClose,
      checkOpen: cashDrawerSession.checkOpen,
      checkCurrent: cashDrawerSession.checkCurrent,
      checkClose: cashDrawerSession.checkClose,
      posOpen: cashDrawerSession.posOpen,
      posCurrent: cashDrawerSession.posCurrent,
      posClose: cashDrawerSession.posClose,
      sessionStartTime: cashDrawerSession.sessionStartTime ? cashDrawerSession.sessionStartTime.format(DATE_TIME_FORMAT) : null,
      sessionEndTime: cashDrawerSession.sessionEndTime ? cashDrawerSession.sessionEndTime.format(DATE_TIME_FORMAT) : null,
      createdBy: cashDrawerSession.createdBy,
      creationDate: cashDrawerSession.creationDate ? cashDrawerSession.creationDate.format(DATE_TIME_FORMAT) : null,
      lastUpdatedBy: cashDrawerSession.lastUpdatedBy,
      lastUpdateDate: cashDrawerSession.lastUpdateDate ? cashDrawerSession.lastUpdateDate.format(DATE_TIME_FORMAT) : null,
      cashDrawer: cashDrawerSession.cashDrawer,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const cashDrawerSession = this.createFromForm();
    if (cashDrawerSession.id !== undefined) {
      this.subscribeToSaveResponse(this.cashDrawerSessionService.update(cashDrawerSession));
    } else {
      this.subscribeToSaveResponse(this.cashDrawerSessionService.create(cashDrawerSession));
    }
  }

  private createFromForm(): ICashDrawerSession {
    return {
      ...new CashDrawerSession(),
      id: this.editForm.get(['id'])!.value,
      currentIndicator: this.editForm.get(['currentIndicator'])!.value,
      cashierUsrCode: this.editForm.get(['cashierUsrCode'])!.value,
      cashOpen: this.editForm.get(['cashOpen'])!.value,
      cashCurrent: this.editForm.get(['cashCurrent'])!.value,
      cashClose: this.editForm.get(['cashClose'])!.value,
      checkOpen: this.editForm.get(['checkOpen'])!.value,
      checkCurrent: this.editForm.get(['checkCurrent'])!.value,
      checkClose: this.editForm.get(['checkClose'])!.value,
      posOpen: this.editForm.get(['posOpen'])!.value,
      posCurrent: this.editForm.get(['posCurrent'])!.value,
      posClose: this.editForm.get(['posClose'])!.value,
      sessionStartTime: this.editForm.get(['sessionStartTime'])!.value
        ? moment(this.editForm.get(['sessionStartTime'])!.value, DATE_TIME_FORMAT)
        : undefined,
      sessionEndTime: this.editForm.get(['sessionEndTime'])!.value
        ? moment(this.editForm.get(['sessionEndTime'])!.value, DATE_TIME_FORMAT)
        : undefined,
      createdBy: this.editForm.get(['createdBy'])!.value,
      creationDate: this.editForm.get(['creationDate'])!.value
        ? moment(this.editForm.get(['creationDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      lastUpdatedBy: this.editForm.get(['lastUpdatedBy'])!.value,
      lastUpdateDate: this.editForm.get(['lastUpdateDate'])!.value
        ? moment(this.editForm.get(['lastUpdateDate'])!.value, DATE_TIME_FORMAT)
        : undefined,
      cashDrawer: this.editForm.get(['cashDrawer'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICashDrawerSession>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ICashDrawer): any {
    return item.id;
  }
}
