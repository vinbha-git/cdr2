import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';

@Component({
  selector: 'jhi-cash-drawer-session-detail',
  templateUrl: './cash-drawer-session-detail.component.html',
})
export class CashDrawerSessionDetailComponent implements OnInit {
  cashDrawerSession: ICashDrawerSession | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawerSession }) => (this.cashDrawerSession = cashDrawerSession));
  }

  previousState(): void {
    window.history.back();
  }
}
