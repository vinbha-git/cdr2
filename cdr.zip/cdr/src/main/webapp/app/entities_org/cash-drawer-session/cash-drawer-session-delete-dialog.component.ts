import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { CashDrawerSessionService } from './cash-drawer-session.service';

@Component({
  templateUrl: './cash-drawer-session-delete-dialog.component.html',
})
export class CashDrawerSessionDeleteDialogComponent {
  cashDrawerSession?: ICashDrawerSession;

  constructor(
    protected cashDrawerSessionService: CashDrawerSessionService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.cashDrawerSessionService.delete(id).subscribe(() => {
      this.eventManager.broadcast('cashDrawerSessionListModification');
      this.activeModal.close();
    });
  }
}
