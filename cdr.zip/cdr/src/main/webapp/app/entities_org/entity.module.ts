import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'cash-drawer',
        loadChildren: () => import('./cash-drawer/cash-drawer.module').then(m => m.CdrCashDrawerModule),
      },
      {
        path: 'cash-drawer-txn',
        loadChildren: () => import('./cash-drawer-txn/cash-drawer-txn.module').then(m => m.CdrCashDrawerTxnModule),
      },
      {
        path: 'cash-drawer-txn-result',
        loadChildren: () => import('./cash-drawer-txn-result/cash-drawer-txn-result.module').then(m => m.CdrCashDrawerTxnResultModule),
      },
      {
        path: 'cash-drawer-payment-txn',
        loadChildren: () => import('./cash-drawer-payment-txn/cash-drawer-payment-txn.module').then(m => m.CdrCashDrawerPaymentTxnModule),
      },
      {
        path: 'cash-drawer-session',
        loadChildren: () => import('./cash-drawer-session/cash-drawer-session.module').then(m => m.CdrCashDrawerSessionModule),
      },
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ]),
  ],
})
export class CdrEntityModule {}
