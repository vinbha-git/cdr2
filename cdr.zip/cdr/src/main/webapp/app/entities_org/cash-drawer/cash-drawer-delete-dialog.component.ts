import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from './cash-drawer.service';

@Component({
  templateUrl: './cash-drawer-delete-dialog.component.html',
})
export class CashDrawerDeleteDialogComponent {
  cashDrawer?: ICashDrawer;

  constructor(
    protected cashDrawerService: CashDrawerService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager
  ) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.cashDrawerService.delete(id).subscribe(() => {
      this.eventManager.broadcast('cashDrawerListModification');
      this.activeModal.close();
    });
  }
}
