import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { ICashDrawer, CashDrawer } from 'app/shared/model/cash-drawer.model';
import { CashDrawerService } from './cash-drawer.service';
import { CashDrawerComponent } from './cash-drawer.component';
import { CashDrawerDetailComponent } from './cash-drawer-detail.component';
import { CashDrawerUpdateComponent } from './cash-drawer-update.component';

@Injectable({ providedIn: 'root' })
export class CashDrawerResolve implements Resolve<ICashDrawer> {
  constructor(private service: CashDrawerService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<ICashDrawer> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((cashDrawer: HttpResponse<CashDrawer>) => {
          if (cashDrawer.body) {
            return of(cashDrawer.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new CashDrawer());
  }
}

export const cashDrawerRoute: Routes = [
  {
    path: '',
    component: CashDrawerComponent,
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawer.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: CashDrawerDetailComponent,
    resolve: {
      cashDrawer: CashDrawerResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawer.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: CashDrawerUpdateComponent,
    resolve: {
      cashDrawer: CashDrawerResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawer.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: CashDrawerUpdateComponent,
    resolve: {
      cashDrawer: CashDrawerResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'cdrApp.cashDrawer.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
];
