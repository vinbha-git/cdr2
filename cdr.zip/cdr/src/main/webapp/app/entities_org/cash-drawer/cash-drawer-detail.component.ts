import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICashDrawer } from 'app/shared/model/cash-drawer.model';

@Component({
  selector: 'jhi-cash-drawer-detail',
  templateUrl: './cash-drawer-detail.component.html',
})
export class CashDrawerDetailComponent implements OnInit {
  cashDrawer: ICashDrawer | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ cashDrawer }) => (this.cashDrawer = cashDrawer));
  }

  previousState(): void {
    window.history.back();
  }
}
