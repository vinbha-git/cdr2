import { Moment } from 'moment';
import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';
import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';
import { DrawerStatus } from 'app/shared/model/enumerations/drawer-status.model';

export interface ICashDrawer {
  id?: number;
  code?: string;
  company?: string;
  branch?: string;
  status?: DrawerStatus;
  cashierUsrCode?: string;
  cashBalance?: number;
  checkBalance?: number;
  posBalance?: number;
  cashLimit?: number;
  changeLimit?: number;
  mainIndicator?: boolean;
  createdBy?: string;
  creationDate?: Moment;
  lastUpdatedBy?: string;
  lastUpdateDate?: Moment;
  cashDrawerTxns?: ICashDrawerTxn[];
  cashDrawerSessions?: ICashDrawerSession[];
}

export class CashDrawer implements ICashDrawer {
  constructor(
    public id?: number,
    public code?: string,
    public company?: string,
    public branch?: string,
    public status?: DrawerStatus,
    public cashierUsrCode?: string,
    public cashBalance?: number,
    public checkBalance?: number,
    public posBalance?: number,
    public cashLimit?: number,
    public changeLimit?: number,
    public mainIndicator?: boolean,
    public createdBy?: string,
    public creationDate?: Moment,
    public lastUpdatedBy?: string,
    public lastUpdateDate?: Moment,
    public cashDrawerTxns?: ICashDrawerTxn[],
    public cashDrawerSessions?: ICashDrawerSession[]
  ) {
    this.mainIndicator = this.mainIndicator || false;
  }
}
