import { Moment } from 'moment';
import { ICashDrawerTxn } from 'app/shared/model/cash-drawer-txn.model';

export interface ICashDrawerTxnResult {
  id?: number;
  systemCashBalance?: number;
  systemCheckBalance?: number;
  systemPosBalance?: number;
  enteredCashBalance?: number;
  enteredCheckBalance?: number;
  enteredPosBalance?: number;
  createdBy?: string;
  creationDate?: Moment;
  lastUpdatedBy?: string;
  lastUpdateDate?: Moment;
  cashDrawerTxn?: ICashDrawerTxn;
}

export class CashDrawerTxnResult implements ICashDrawerTxnResult {
  constructor(
    public id?: number,
    public systemCashBalance?: number,
    public systemCheckBalance?: number,
    public systemPosBalance?: number,
    public enteredCashBalance?: number,
    public enteredCheckBalance?: number,
    public enteredPosBalance?: number,
    public createdBy?: string,
    public creationDate?: Moment,
    public lastUpdatedBy?: string,
    public lastUpdateDate?: Moment,
    public cashDrawerTxn?: ICashDrawerTxn
  ) {}
}
