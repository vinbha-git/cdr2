import { Moment } from 'moment';
import { ICashDrawerPaymentTxn } from 'app/shared/model/cash-drawer-payment-txn.model';
import { ICashDrawer } from 'app/shared/model/cash-drawer.model';

export interface ICashDrawerSession {
  id?: number;
  currentIndicator?: boolean;
  cashierUsrCode?: string;
  cashOpen?: number;
  cashCurrent?: number;
  cashClose?: number;
  checkOpen?: number;
  checkCurrent?: number;
  checkClose?: number;
  posOpen?: number;
  posCurrent?: number;
  posClose?: number;
  sessionStartTime?: Moment;
  sessionEndTime?: Moment;
  createdBy?: string;
  creationDate?: Moment;
  lastUpdatedBy?: string;
  lastUpdateDate?: Moment;
  cashDrawerPaymentTxns?: ICashDrawerPaymentTxn[];
  cashDrawer?: ICashDrawer;
}

export class CashDrawerSession implements ICashDrawerSession {
  constructor(
    public id?: number,
    public currentIndicator?: boolean,
    public cashierUsrCode?: string,
    public cashOpen?: number,
    public cashCurrent?: number,
    public cashClose?: number,
    public checkOpen?: number,
    public checkCurrent?: number,
    public checkClose?: number,
    public posOpen?: number,
    public posCurrent?: number,
    public posClose?: number,
    public sessionStartTime?: Moment,
    public sessionEndTime?: Moment,
    public createdBy?: string,
    public creationDate?: Moment,
    public lastUpdatedBy?: string,
    public lastUpdateDate?: Moment,
    public cashDrawerPaymentTxns?: ICashDrawerPaymentTxn[],
    public cashDrawer?: ICashDrawer
  ) {
    this.currentIndicator = this.currentIndicator || false;
  }
}
