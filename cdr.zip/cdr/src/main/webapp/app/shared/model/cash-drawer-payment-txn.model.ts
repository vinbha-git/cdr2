import { Moment } from 'moment';
import { ICashDrawerSession } from 'app/shared/model/cash-drawer-session.model';

export interface ICashDrawerPaymentTxn {
  id?: number;
  txnDate?: Moment;
  customerFirstName?: string;
  customerLastName?: string;
  customerNbr?: string;
  customerPhone?: number;
  cstomerAccountNumber?: string;
  dueAmt?: number;
  cashAmt?: number;
  checkAmt?: number;
  posAmt?: number;
  changeAmt?: number;
  checkNumber?: string;
  posReference?: string;
  createdBy?: string;
  creationDate?: Moment;
  lastUpdatedBy?: string;
  lastUpdateDate?: Moment;
  cashDrawerSession?: ICashDrawerSession;
}

export class CashDrawerPaymentTxn implements ICashDrawerPaymentTxn {
  constructor(
    public id?: number,
    public txnDate?: Moment,
    public customerFirstName?: string,
    public customerLastName?: string,
    public customerNbr?: string,
    public customerPhone?: number,
    public cstomerAccountNumber?: string,
    public dueAmt?: number,
    public cashAmt?: number,
    public checkAmt?: number,
    public posAmt?: number,
    public changeAmt?: number,
    public checkNumber?: string,
    public posReference?: string,
    public createdBy?: string,
    public creationDate?: Moment,
    public lastUpdatedBy?: string,
    public lastUpdateDate?: Moment,
    public cashDrawerSession?: ICashDrawerSession
  ) {}
}
