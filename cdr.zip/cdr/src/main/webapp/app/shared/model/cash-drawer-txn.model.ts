import { Moment } from 'moment';
import { ICashDrawerTxnResult } from 'app/shared/model/cash-drawer-txn-result.model';
import { ICashDrawer } from 'app/shared/model/cash-drawer.model';
import { TxnCode } from 'app/shared/model/enumerations/txn-code.model';
import { TxnStatus } from 'app/shared/model/enumerations/txn-status.model';

export interface ICashDrawerTxn {
  id?: number;
  txnDate?: Moment;
  txnCode?: TxnCode;
  txnStatus?: TxnStatus;
  txnAuthorisedUserCode?: string;
  txnAuthorisedDate?: Moment;
  txnAuthorisedReason?: Moment;
  totalCoinAmt?: number;
  totalNoteAmt?: number;
  totalCheckAmt?: number;
  totalPosAmt?: number;
  coinCent1Roll?: number;
  coinCent1Lose?: number;
  coinCent5Roll?: number;
  coinCent5Loose?: number;
  coinCent10Roll?: number;
  coinCent10Loose?: number;
  coinCent25Roll?: number;
  coinCent25Loose?: number;
  coinCent50Roll?: number;
  coinCent50Loose?: number;
  coinDollar1Roll?: number;
  coinDollar1Loose?: number;
  noteDollar1Bundle?: number;
  noteDollar1Loose?: number;
  noteDollar2Bundle?: number;
  noteDollar2Loose?: number;
  noteDollar5Bundle?: number;
  noteDollar5Loose?: number;
  noteDollar10Bundle?: number;
  noteDollar10Loose?: number;
  noteDollar20Bundle?: number;
  noteDollar20Loose?: number;
  noteDollar50Bundle?: number;
  noteDollar50Loose?: number;
  noteDollar100Bundle?: number;
  noteDollar100Loose?: number;
  createdBy?: string;
  creationDate?: Moment;
  lastUpdatedBy?: string;
  lastUpdateDate?: Moment;
  cashDrawerTxnResults?: ICashDrawerTxnResult[];
  cashDrawer?: ICashDrawer;
}

export class CashDrawerTxn implements ICashDrawerTxn {
  constructor(
    public id?: number,
    public txnDate?: Moment,
    public txnCode?: TxnCode,
    public txnStatus?: TxnStatus,
    public txnAuthorisedUserCode?: string,
    public txnAuthorisedDate?: Moment,
    public txnAuthorisedReason?: Moment,
    public totalCoinAmt?: number,
    public totalNoteAmt?: number,
    public totalCheckAmt?: number,
    public totalPosAmt?: number,
    public coinCent1Roll?: number,
    public coinCent1Lose?: number,
    public coinCent5Roll?: number,
    public coinCent5Loose?: number,
    public coinCent10Roll?: number,
    public coinCent10Loose?: number,
    public coinCent25Roll?: number,
    public coinCent25Loose?: number,
    public coinCent50Roll?: number,
    public coinCent50Loose?: number,
    public coinDollar1Roll?: number,
    public coinDollar1Loose?: number,
    public noteDollar1Bundle?: number,
    public noteDollar1Loose?: number,
    public noteDollar2Bundle?: number,
    public noteDollar2Loose?: number,
    public noteDollar5Bundle?: number,
    public noteDollar5Loose?: number,
    public noteDollar10Bundle?: number,
    public noteDollar10Loose?: number,
    public noteDollar20Bundle?: number,
    public noteDollar20Loose?: number,
    public noteDollar50Bundle?: number,
    public noteDollar50Loose?: number,
    public noteDollar100Bundle?: number,
    public noteDollar100Loose?: number,
    public createdBy?: string,
    public creationDate?: Moment,
    public lastUpdatedBy?: string,
    public lastUpdateDate?: Moment,
    public cashDrawerTxnResults?: ICashDrawerTxnResult[],
    public cashDrawer?: ICashDrawer
  ) {}
}
